/* 의사소통장애 퀴즈 — 서버 핵심 로직 (Apps Script와 로컬 시험에서 같이 씀)
 * 정답·채점 기준은 이 파일과 BANK에만 있다. 학생에게 보내는 문항에서는 정답을 지운다.
 * store 인터페이스: getSession(id), putSession(s), listSessions(), deleteSession(id),
 *   getAttempt(sid,no), putAttempt(a), listAttempts(sid), listAttemptsByStudent(no), deleteAttempt(sid,no),
 *   getProp(k), setProp(k,v), log(row), now(), random(), sha256(str), cacheGet(k), cachePut(k,v,sec)
 */
var CORE_VERSION = '1.2.0';
var VIOLATION_LIMIT = 2;          // 2회째에 즉시 종료·0점
var TIME_GRACE_MS = 90 * 1000;    // 제한 시간 뒤 제출 허용 여유

function Core(store, bank, outline) {
  this.s = store; this.bank = bank; this.outline = outline;
  this.order = {}; var self = this;
  outline.forEach(function (n, i) { self.order[n.id] = i; });
  this.byId = {};
  bank.questions.forEach(function (q) { self.byId[q.id] = q; });
  (bank.imyong || []).forEach(function (q) { self.byId[q.id] = q; });
  (bank.orig || []).forEach(function (q) { self.byId[q.id] = q; });
}

/* ---------- 공통 도구 ---------- */
function normNo(v) { return String(v || '').replace(/\s+/g, '').toUpperCase().slice(0, 20); }
function normName(v) { return String(v || '').normalize('NFC').replace(/\s+/g, ' ').trim().slice(0, 40); }
function normAns(v) {
  return String(v || '').normalize('NFC').toLowerCase()
    .replace(/[\s·.,'"‘’“”`~!?()\[\]{}<>「」『』〈〉《》\-_/:;]/g, '');
}
function err(code, msg) { var e = new Error(msg || code); e.code = code; return e; }
function pick(obj, keys) { var o = {}; keys.forEach(function (k) { if (obj[k] !== undefined) o[k] = obj[k]; }); return o; }
function round1(x) { return Math.round(x * 10) / 10; }

Core.prototype.rand = function () { return this.s.random(); };
Core.prototype.shuffle = function (arr) {
  var a = arr.slice();
  for (var i = a.length - 1; i > 0; i--) { var j = Math.floor(this.rand() * (i + 1)); var t = a[i]; a[i] = a[j]; a[j] = t; }
  return a;
};
Core.prototype.newId = function (prefix) {
  var c = 'abcdefghijkmnpqrstuvwxyz23456789', s = '';
  for (var i = 0; i < 10; i++) s += c[Math.floor(this.rand() * c.length)];
  return (prefix || '') + s;
};

/* ---------- 범위 ---------- */
// range = {start: nodeId|null, end: nodeId|null}. start 노드의 첫 하위부터 end 노드의 마지막 하위까지.
Core.prototype.rangeUnits = function (range) {
  var o = this.outline, n = o.length;
  var si = 0, ei = n - 1;
  if (range && range.start && this.order[range.start] !== undefined) si = this.order[range.start];
  if (range && range.end && this.order[range.end] !== undefined) {
    ei = this.order[range.end];
    // end 노드의 하위 노드들까지 포함
    var lv = o[ei].level, ch = o[ei].ch;
    while (ei + 1 < n && o[ei + 1].ch === ch && o[ei + 1].level > lv) ei++;
    if (o[this.order[range.end]].level === 0) { while (ei + 1 < n && o[ei + 1].ch === ch) ei++; }
  }
  if (si > ei) { var t = si; si = ei; ei = t; }
  var ids = {};
  for (var i = si; i <= ei; i++) ids[o[i].id] = true;
  return ids;
};
Core.prototype.pageSet = function (units) {
  var pages = {}, self = this;
  this.outline.forEach(function (n) { if (units[n.id]) (n.pages || []).forEach(function (p) { pages[p] = true; }); });
  return pages;
};

/* ---------- 출제 ---------- */
Core.prototype.candidates = function (range, type, opts) {
  opts = opts || {};
  var units = this.rangeUnits(range), self = this;
  var used = opts.excludeUsed ? this.usedIds() : {};
  var ex = {}; (opts.excludeIds || []).forEach(function (id) { ex[id] = true; });
  if (type === 'imyong' || type === 'orig') {
    var pages = this.pageSet(units);
    return (type === 'orig' ? (this.bank.orig || []) : (this.bank.imyong || [])).filter(function (q) {
      if (ex[q.id] || used[q.id]) return false;
      if (q.unit) return !!units[q.unit];   // 단원이 정해진 문항은 그 단원이 범위 안일 때만
      return (q.lecturePages || []).some(function (p) { return pages[p]; });
    });
  }
  return this.bank.questions.filter(function (q) {
    return q.type === type && units[q.unit] && !ex[q.id] && !used[q.id];
  });
};
Core.prototype.usedIds = function () {
  var used = {};
  this.s.listSessions().forEach(function (s) { (s.questions || []).forEach(function (q) { if (q.bankId) used[q.bankId] = true; }); });
  return used;
};
// 단원을 고르게: 단원별로 묶어 섞은 뒤 돌아가며 뽑는다.
Core.prototype.spread = function (list, k, takenUnits) {
  var self = this, groups = {}, keys = [];
  this.shuffle(list).forEach(function (q) {
    var u = q.unit || (q.lecturePages || [''])[0];
    if (!groups[u]) { groups[u] = []; keys.push(u); }
    groups[u].push(q);
  });
  // 이미 뽑힌 단원은 뒤로
  var prefer = !!this.preferImportant, W = { '상': 3, '중': 2, '하': 1 };
  keys = this.shuffle(keys).sort(function (a, b) {
    var t = (takenUnits[a] || 0) - (takenUnits[b] || 0); if (t) return t;
    return prefer ? (W[self.gradeOf(b)] || 0) - (W[self.gradeOf(a)] || 0) : 0;
  });
  var out = [];
  while (out.length < k) {
    var progressed = false;
    for (var i = 0; i < keys.length && out.length < k; i++) {
      var g = groups[keys[i]];
      if (g.length) { var q = g.shift(); out.push(q); takenUnits[keys[i]] = (takenUnits[keys[i]] || 0) + 1; progressed = true; }
    }
    if (!progressed) break;
  }
  return out;
};
// 단원의 임용 출제 중요도: 그 단원 등급, 없으면 가장 가까운 상위 단원 등급
Core.prototype.gradeOf = function (unitId) {
  var i = this.order[unitId]; if (i === undefined) return null;
  var n = this.outline[i]; if (n.imp && n.imp.grade) return n.imp.grade;
  var lv = n.level;
  for (var j = i - 1; j >= 0 && lv > 0; j--) {
    var m = this.outline[j]; if (m.ch !== n.ch) break;
    if (m.level < lv) { if (m.level > 0 && m.imp && m.imp.grade) return m.imp.grade; lv = m.level; }
  }
  return null;
};
Core.prototype.generate = function (p) {
  this.preferImportant = p.preferImportant !== false;
  var counts = p.counts || {};
  var total = (counts.mc || 0) + (counts.short || 0) + (counts.essay || 0) + (counts.imyong || 0) + (counts.orig || 0);
  if (total < 5 || total > 10) throw err('bad_count', '문항 수는 5개에서 10개 사이여야 합니다.');
  var taken = {}, out = [], short = [], self = this;
  ['orig', 'mc', 'short', 'essay', 'imyong'].forEach(function (t) {
    var k = counts[t] || 0; if (!k) return;
    var got = self.spread(self.candidates(p.range, t, p), k, taken);
    if (got.length < k) short.push({ type: t, want: k, got: got.length, optional: t === 'orig' });
    out = out.concat(got);
  });
  // 자료 순서대로 정렬(기출 변형은 해당 단원 위치)
  if (out.length < 5) throw err('bad_count', '범위 안 문항이 모자라 ' + out.length + '문항만 뽑혔습니다. 범위를 넓히거나 유형 수를 바꾸세요.');
  out.sort(function (a, b) { return self.qOrder(a) - self.qOrder(b); });
  return { questions: out.map(function (q) { return self.toSessionQ(q); }), shortage: short };
};
Core.prototype.qOrder = function (q) {
  if (q.unit && this.order[q.unit] !== undefined) return this.order[q.unit] + (q.kind === 'imyong' || q.kind === 'orig' ? 0.5 : 0);
  var pg = (q.lecturePages || [])[0], self = this, best = 1e9;
  this.outline.forEach(function (n, i) { if ((n.pages || []).indexOf(pg) >= 0 && i < best) best = i; });
  return best + 0.5;
};
Core.prototype.regenOne = function (p) {
  this.preferImportant = p.preferImportant !== false;
  var t = p.type, self = this;
  var list = this.candidates(p.range, t, p);
  if (!list.length) throw err('no_more', '범위 안에 바꿀 문항이 더 없습니다.');
  var q = list[Math.floor(this.rand() * list.length)];
  return { question: this.toSessionQ(q) };
};
// 은행 문항 → 회기 문항(정답 포함 복사본. 교수가 고칠 수 있음)
Core.prototype.toSessionQ = function (q) {
  var kind = q.kind === 'orig' || String(q.id).indexOf('or-') === 0 ? 'orig' : (String(q.id).indexOf('im-') === 0 || q.code) ? 'imyong' : 'bank';
  var o = {
    bankId: q.id, kind: kind, type: q.type, stem: q.stem,
    options: q.options ? q.options.slice() : undefined, answer: q.answer,
    accept: q.accept ? q.accept.slice() : undefined,
    keyPoints: q.keyPoints ? JSON.parse(JSON.stringify(q.keyPoints)) : undefined,
    model: q.model, explain: q.explain || '', source: q.source || (q.lecturePages || []).join(', '),
    unit: q.unit || null, code: q.code || null, level: q.level || null, grade: this.gradeOf(q.unit) || null
  };
  Object.keys(o).forEach(function (k) { if (o[k] === undefined) delete o[k]; });
  return o;
};
Core.prototype.validQ = function (q) {
  if (['mc', 'short', 'essay'].indexOf(q.type) < 0) throw err('bad_q', '문항 유형 오류');
  if (!q.stem || String(q.stem).length > 4000) throw err('bad_q', '발문이 비었거나 너무 깁니다.');
  if (q.type === 'mc') {
    if (!q.options || q.options.length < 2 || q.options.length > 6) throw err('bad_q', '객관식 보기 수 오류');
    if (!(q.answer >= 0 && q.answer < q.options.length)) throw err('bad_q', '객관식 정답 번호 오류');
  }
  if (q.type === 'short' && (!q.accept || !q.accept.filter(String).length)) throw err('bad_q', '단답형 정답이 없습니다.');
  if (q.type === 'essay' && (!q.keyPoints || !q.keyPoints.length)) throw err('bad_q', '서술형 채점 요소가 없습니다.');
  return q;
};

/* ---------- 회기 ---------- */
Core.prototype.createSession = function (p) {
  var qs = (p.questions || []).map(this.validQ.bind(this));
  if (qs.length < 5 || qs.length > 10) throw err('bad_count', '문항 수는 5개에서 10개 사이여야 합니다.');
  var now = this.s.now();
  var sess = {
    id: this.newId('s'), title: String(p.title || '퀴즈').slice(0, 80),
    range: p.range || null, rangeLabel: String(p.rangeLabel || '').slice(0, 300),
    questions: qs.map(function (q, i) { q.qid = 'q' + (i + 1); return q; }),
    timeLimit: Math.max(0, Math.min(180, Number(p.timeLimit) || 0)),
    showResult: p.showResult === 'immediate' ? 'immediate' : 'after',
    shuffle: !!p.shuffle, released: p.showResult === 'immediate',
    status: p.status === 'open' ? 'open' : 'draft',
    createdAt: now, updatedAt: now, openedAt: p.status === 'open' ? now : null, closedAt: null
  };
  this.s.putSession(sess);
  return { session: sess };
};
Core.prototype.updateSession = function (p) {
  var s = this.s.getSession(p.id); if (!s) throw err('not_found', '회기가 없습니다.');
  var patch = p.patch || {}, now = this.s.now();
  if (patch.status && ['draft', 'open', 'closed'].indexOf(patch.status) >= 0) {
    if (patch.status === 'open' && s.status !== 'open') s.openedAt = now;
    if (patch.status === 'closed' && s.status !== 'closed') s.closedAt = now;
    s.status = patch.status;
  }
  if (patch.title !== undefined) s.title = String(patch.title).slice(0, 80);
  if (patch.released !== undefined) s.released = !!patch.released;
  if (patch.timeLimit !== undefined) s.timeLimit = Math.max(0, Math.min(180, Number(patch.timeLimit) || 0));
  if (patch.questions && s.status === 'draft') {
    var qs = patch.questions.map(this.validQ.bind(this));
    if (qs.length < 5 || qs.length > 10) throw err('bad_count', '문항 수는 5개에서 10개 사이여야 합니다.');
    s.questions = qs.map(function (q, i) { q.qid = 'q' + (i + 1); return q; });
  }
  s.updatedAt = now;
  this.s.putSession(s);
  return { session: s };
};
Core.prototype.deleteSession = function (p) {
  var self = this;
  this.s.listAttempts(p.id).forEach(function (a) { self.s.deleteAttempt(p.id, a.no); });
  this.s.deleteSession(p.id);
  return { ok: true };
};
Core.prototype.publicSession = function (s) {
  var o = pick(s, ['id', 'title', 'rangeLabel', 'timeLimit', 'status', 'showResult', 'released', 'openedAt', 'closedAt', 'createdAt']);
  o.n = s.questions.length;
  o.types = s.questions.map(function (q) { return q.type; });
  return o;
};
Core.prototype.listOpen = function () {
  var self = this;
  return {
    sessions: this.s.listSessions().filter(function (s) { return s.status === 'open'; })
      .sort(function (a, b) { return (b.openedAt || 0) - (a.openedAt || 0); })
      .map(function (s) { return self.publicSession(s); })
  };
};

/* ---------- 명단 ---------- */
Core.prototype.getRoster = function () { var r = this.s.getProp('ROSTER'); return r ? JSON.parse(r) : []; };
Core.prototype.setRoster = function (p) {
  var list = (p.roster || []).map(function (r) { return { no: normNo(r.no), name: normName(r.name) }; })
    .filter(function (r) { return r.no && r.name; });
  this.s.setProp('ROSTER', JSON.stringify(list));
  return { roster: list };
};
Core.prototype.checkStudent = function (no, name) {
  if (!no || no.length < 4) throw err('bad_no', '학번을 확인해 주세요.');
  if (!name) throw err('bad_name', '이름을 입력해 주세요.');
  var roster = this.getRoster();
  if (roster.length) {
    var hit = roster.filter(function (r) { return r.no === no; })[0];
    if (!hit) throw err('not_in_roster', '수강생 명단에 없는 학번입니다. 담당 교수님께 알려 주세요.');
    if (hit.name.replace(/\s/g, '') !== name.replace(/\s/g, '')) throw err('name_mismatch', '학번과 이름이 명단과 맞지 않습니다.');
  }
  // 같은 학번이 다른 이름으로 응시한 적이 있으면 막는다
  var prev = this.s.listAttemptsByStudent(no);
  for (var i = 0; i < prev.length; i++) {
    if (prev[i].name.replace(/\s/g, '') !== name.replace(/\s/g, '')) throw err('name_mismatch', '이 학번은 다른 이름으로 응시 기록이 있습니다. 담당 교수님께 알려 주세요.');
  }
};

/* ---------- 학생 응시 ---------- */
Core.prototype.studentView = function (s, a) {
  // 정답·채점 기준을 지운 문항, 학생별 순서
  var byQ = {}; s.questions.forEach(function (q) { byQ[q.qid] = q; });
  var qs = a.order.map(function (qid) {
    var q = byQ[qid];
    var v = { qid: q.qid, type: q.type, stem: q.stem, kind: q.kind, code: q.code || null };
    if (q.type === 'mc') {
      var perm = a.optOrder[qid] || q.options.map(function (_, i) { return i; });
      v.options = perm.map(function (i) { return q.options[i]; });
    }
    if (q.type === 'essay') v.items = (q.keyPoints || []).length;
    return v;
  });
  return qs;
};
Core.prototype.attemptState = function (s, a, extra) {
  var out = {
    session: this.publicSession(s), status: a.status, violations: a.violations.length,
    violationLimit: VIOLATION_LIMIT, startedAt: a.startedAt, serverNow: this.s.now(),
    deadline: s.timeLimit ? a.startedAt + s.timeLimit * 60000 : null, token: a.token
  };
  if (a.status === 'in_progress') {
    out.questions = this.studentView(s, a);
    out.answers = this.toDisplayAnswers(s, a, a.answers);
  } else {
    out.result = this.resultFor(s, a);
  }
  if (extra) Object.keys(extra).forEach(function (k) { out[k] = extra[k]; });
  return out;
};
// 저장된 답(원래 보기 번호) → 학생 화면 보기 번호
Core.prototype.toDisplayAnswers = function (s, a, ans) {
  var out = {};
  Object.keys(ans || {}).forEach(function (qid) {
    var v = ans[qid], perm = a.optOrder[qid];
    if (perm && typeof v === 'number') out[qid] = perm.indexOf(v); else out[qid] = v;
  });
  return out;
};
Core.prototype.fromDisplayAnswers = function (s, a, ans) {
  var byQ = {}; s.questions.forEach(function (q) { byQ[q.qid] = q; });
  var out = {};
  Object.keys(ans || {}).forEach(function (qid) {
    var q = byQ[qid]; if (!q) return;
    var v = ans[qid];
    if (q.type === 'mc') {
      var n = Number(v); if (!(n >= 0 && n < q.options.length)) return;
      var perm = a.optOrder[qid]; out[qid] = perm ? perm[n] : n;
    } else {
      out[qid] = String(v == null ? '' : v).slice(0, q.type === 'essay' ? 3000 : 200);
    }
  });
  return out;
};
Core.prototype.enter = function (p) {
  var no = normNo(p.studentNo), name = normName(p.name);
  this.checkStudent(no, name);
  var s = this.s.getSession(p.sid);
  if (!s) throw err('not_found', '시험을 찾을 수 없습니다.');
  var a = this.s.getAttempt(s.id, no), now = this.s.now(), self = this;
  if (!a) {
    if (s.status !== 'open') throw err('closed', '지금은 응시할 수 없는 시험입니다.');
    var qids = s.questions.map(function (q) { return q.qid; });
    var order = s.shuffle ? this.shuffle(qids) : qids;
    var optOrder = {};
    s.questions.forEach(function (q) {
      if (q.type === 'mc' && s.shuffle) optOrder[q.qid] = self.shuffle(q.options.map(function (_, i) { return i; }));
    });
    a = {
      sid: s.id, no: no, name: name, status: 'in_progress', startedAt: now, updatedAt: now,
      token: this.newId('t') + this.newId(''), order: order, optOrder: optOrder, answers: {},
      violations: [], device: String(p.device || '').slice(0, 120), entries: 1
    };
    this.s.putAttempt(a);
    this.s.log([now, s.id, no, 'start', a.device]);
    return this.attemptState(s, a, { first: true });
  }
  if (a.name.replace(/\s/g, '') !== name.replace(/\s/g, '')) throw err('name_mismatch', '학번과 이름이 처음 응시 때와 다릅니다.');
  if (a.status === 'in_progress') {
    // 앱을 닫았거나 새로고침한 뒤 다시 들어온 것 → 이탈 1회
    a.entries = (a.entries || 1) + 1;
    if (s.timeLimit && now > a.startedAt + s.timeLimit * 60000 + TIME_GRACE_MS) {
      this.finish(s, a, 'timeout');
      return this.attemptState(s, a);
    }
    var last = a.violations[a.violations.length - 1];
    if (last && last.returned === false) {
      // 화면을 벗어난 채로 앱을 닫았다가 다시 들어온 경우: 같은 이탈 한 번으로 본다
      last.returned = true; last.reentered = now; a.updatedAt = now; this.s.putAttempt(a);
      this.s.log([now, s.id, no, 'reenter', '같은 이탈에 이어 재입장']);
      return this.attemptState(s, a, { reentered: true, warned: false });
    }
    var info = this.addViolation(s, a, { kind: 'reenter', eventId: 'reenter-' + a.entries, at: now, detail: String(p.device || '').slice(0, 120), returned: true });
    return this.attemptState(s, a, { reentered: true, warned: info.added });
  }
  return this.attemptState(s, a);
};
Core.prototype.auth = function (p) {
  var no = normNo(p.studentNo);
  var a = this.s.getAttempt(p.sid, no);
  if (!a || !p.token || a.token !== p.token) throw err('bad_token', '응시 정보가 맞지 않습니다. 다시 입장해 주세요.');
  var s = this.s.getSession(p.sid);
  if (!s) throw err('not_found', '시험을 찾을 수 없습니다.');
  return { s: s, a: a };
};
Core.prototype.save = function (p) {
  var x = this.auth(p), s = x.s, a = x.a;
  if (a.status !== 'in_progress') return this.attemptState(s, a);
  var ans = this.fromDisplayAnswers(s, a, p.answers);
  Object.keys(ans).forEach(function (k) { a.answers[k] = ans[k]; });
  a.updatedAt = this.s.now();
  this.s.putAttempt(a);
  return { ok: true, status: a.status, violations: a.violations.length, savedAt: a.updatedAt };
};
Core.prototype.addViolation = function (s, a, ev) {
  var hit = a.violations.filter(function (v) { return v.eventId === ev.eventId; })[0];
  if (hit) {
    if (ev.returned && hit.returned === false) { hit.returned = true; hit.backAt = this.s.now(); a.updatedAt = this.s.now(); this.s.putAttempt(a); }
    return { added: false };
  }
  if (a.status !== 'in_progress') return { added: false };
  a.violations.push({ eventId: String(ev.eventId).slice(0, 60), kind: String(ev.kind || 'hidden').slice(0, 20), at: this.s.now(), clientAt: ev.at || null, detail: String(ev.detail || '').slice(0, 120), returned: !!ev.returned });
  this.s.log([this.s.now(), s.id, a.no, 'violation', ev.kind + ' #' + a.violations.length]);
  if (a.violations.length >= VIOLATION_LIMIT) this.finish(s, a, 'violation');
  else { a.updatedAt = this.s.now(); this.s.putAttempt(a); }
  return { added: true };
};
Core.prototype.violation = function (p) {
  var x = this.auth(p), s = x.s, a = x.a;
  if (p.answers && a.status === 'in_progress') {
    var ans = this.fromDisplayAnswers(s, a, p.answers);
    Object.keys(ans).forEach(function (k) { a.answers[k] = ans[k]; });
  }
  if (!p.eventId) throw err('bad_event', '기록 번호가 없습니다.');
  var r = this.addViolation(s, a, { kind: ['hidden', 'blur', 'leave'].indexOf(p.kind) >= 0 ? p.kind : 'hidden', eventId: p.eventId, at: p.at, detail: p.detail, returned: p.phase === 'return' });
  return { added: r.added, status: a.status, violations: a.violations.length, violationLimit: VIOLATION_LIMIT, result: a.status !== 'in_progress' ? this.resultFor(s, a) : undefined };
};
Core.prototype.submit = function (p) {
  var x = this.auth(p), s = x.s, a = x.a;
  if (a.status === 'in_progress') {
    var ans = this.fromDisplayAnswers(s, a, p.answers);
    Object.keys(ans).forEach(function (k) { a.answers[k] = ans[k]; });
    var late = s.timeLimit && this.s.now() > a.startedAt + s.timeLimit * 60000 + TIME_GRACE_MS;
    this.finish(s, a, late ? 'timeout' : (p.auto ? 'auto' : 'submit'));
  }
  return this.attemptState(s, a);
};

/* ---------- 채점 ---------- */
Core.prototype.gradeOne = function (q, v, manual) {
  // 반환 {frac, auto, detail}
  if (manual && manual[q.qid] !== undefined && manual[q.qid] !== null) {
    return { frac: Math.max(0, Math.min(1, Number(manual[q.qid]))), manual: true };
  }
  if (q.type === 'mc') return { frac: v === q.answer ? 1 : 0 };
  if (q.type === 'short') {
    var a = normAns(v); if (!a) return { frac: 0 };
    var ok = (q.accept || []).some(function (t) {
      var n = normAns(t); if (!n) return false;
      if (a === n) return true;
      return n.length >= 2 && a.indexOf(n) >= 0 && a.length <= n.length + 8;
    });
    return { frac: ok ? 1 : 0 };
  }
  if (q.type === 'essay') {
    var txt = normAns(v), hits = [], tot = 0, got = 0;
    (q.keyPoints || []).forEach(function (kp, i) {
      var pts = Number(kp.pts) || 1; tot += pts;
      var hit = txt && (kp.keywords || []).some(function (k) { var n = normAns(k); return n && txt.indexOf(n) >= 0; });
      if (hit) { got += pts; hits.push(i); }
    });
    return { frac: tot ? got / tot : 0, provisional: true, hits: hits };
  }
  return { frac: 0 };
};
Core.prototype.score = function (s, a) {
  if (a.status === 'terminated') return { total: 0, items: {}, pending: 0 };
  var self = this, items = {}, sum = 0, pending = 0, n = s.questions.length;
  s.questions.forEach(function (q) {
    var g = self.gradeOne(q, a.answers[q.qid], a.manual);
    if (q.type === 'essay' && !g.manual) pending++;
    items[q.qid] = g; sum += g.frac;
  });
  return { total: round1(sum / n * 100), items: items, pending: pending };
};
Core.prototype.finish = function (s, a, why) {
  var now = this.s.now();
  if (why === 'violation') { a.status = 'terminated'; a.endReason = 'violation'; }
  else { a.status = 'submitted'; a.endReason = why; }
  a.submittedAt = now; a.updatedAt = now;
  var sc = this.score(s, a); a.score = sc.total; a.pending = sc.pending;
  this.s.putAttempt(a);
  this.s.log([now, s.id, a.no, a.status, why + ' ' + a.score]);
};
Core.prototype.resultFor = function (s, a) {
  var r = { status: a.status, endReason: a.endReason, submittedAt: a.submittedAt, released: !!s.released };
  if (a.status === 'terminated') { r.score = 0; r.message = '화면 이탈이 ' + VIOLATION_LIMIT + '회 기록되어 시험이 종료되었고 0점 처리되었습니다.'; }
  if (!s.released) return r;
  var sc = this.score(s, a), self = this;
  r.score = sc.total; r.pending = sc.pending;
  if (a.status === 'terminated') r.score = 0;
  r.items = a.order.map(function (qid, i) {
    var q = s.questions.filter(function (x) { return x.qid === qid; })[0];
    var g = sc.items[qid] || { frac: 0 }, v = a.answers[qid];
    var it = { no: i + 1, kind: q.kind, grade: q.grade || null, type: q.type, stem: q.stem, frac: a.status === 'terminated' ? 0 : g.frac, provisional: !!g.provisional && !g.manual, explain: q.explain, source: q.source, code: q.code || null };
    if (q.type === 'mc') {
      var perm = a.optOrder[qid] || q.options.map(function (_, k) { return k; });
      it.options = perm.map(function (k) { return q.options[k]; });
      it.mine = typeof v === 'number' ? perm.indexOf(v) : null;
      it.correct = perm.indexOf(q.answer);
    } else if (q.type === 'short') { it.mine = v || ''; it.correct = (q.accept || [])[0]; }
    else { it.mine = v || ''; it.model = q.model || ''; it.points = (q.keyPoints || []).map(function (k) { return k.point; }); }
    return it;
  });
  return r;
};

/* ---------- 학생 기록 ---------- */
Core.prototype.myHistory = function (p) {
  var no = normNo(p.studentNo), name = normName(p.name), self = this;
  if (!no || !name) throw err('bad_no', '학번과 이름을 입력해 주세요.');
  var mine = this.s.listAttemptsByStudent(no).filter(function (a) { return a.name.replace(/\s/g, '') === name.replace(/\s/g, ''); });
  var out = [];
  mine.forEach(function (a) {
    var s = self.s.getSession(a.sid); if (!s || a.status === 'in_progress') return;
    var row = { sid: s.id, title: s.title, at: a.submittedAt, status: a.status, released: !!s.released };
    if (s.released) {
      row.score = a.status === 'terminated' ? 0 : self.score(s, a).total;
      var all = self.s.listAttempts(s.id).filter(function (x) { return x.status !== 'in_progress'; });
      row.classAvg = all.length ? round1(all.reduce(function (t, x) { return t + (x.status === 'terminated' ? 0 : self.score(s, x).total); }, 0) / all.length) : null;
      row.classN = all.length;
    }
    out.push(row);
  });
  out.sort(function (x, y) { return (x.at || 0) - (y.at || 0); });
  return { history: out };
};

// 학생이 지난 시험 결과를 다시 보기(교수가 공개한 회기만 문항별 내용이 나간다)
Core.prototype.myResult = function (p) {
  var no = normNo(p.studentNo), name = normName(p.name);
  var s = this.s.getSession(p.sid), a = s ? this.s.getAttempt(s.id, no) : null;
  if (!s || !a || a.name.replace(/\s/g, '') !== name.replace(/\s/g, '')) throw err('not_found', '응시 기록을 찾을 수 없습니다.');
  if (a.status === 'in_progress') throw err('in_progress', '아직 응시 중인 시험입니다.');
  return { session: this.publicSession(s), status: a.status, result: this.resultFor(s, a) };
};

/* ---------- 교수 ---------- */
Core.prototype.adminLogin = function (p) {
  var hash = this.s.getProp('ADMIN_PW_HASH'), plain = this.s.getProp('ADMIN_PW');
  if (!hash && !plain) throw err('no_pw', '교수 비밀번호가 아직 설정되지 않았습니다. Apps Script 프로젝트 설정 → 스크립트 속성에 ADMIN_PW를 넣어 주세요.');
  var tries = Number(this.s.cacheGet('pwfail') || 0);
  if (tries >= 8) throw err('locked', '비밀번호를 여러 번 틀려 10분 동안 잠겼습니다.');
  var ok = hash ? this.s.sha256('quiz|' + p.pw) === hash : String(p.pw) === String(plain);
  if (!ok) { this.s.cachePut('pwfail', String(tries + 1), 600); throw err('bad_pw', '비밀번호가 맞지 않습니다.'); }
  var t = this.newId('a') + this.newId('') + this.newId('');
  this.s.cachePut('adm_' + t, '1', 6 * 3600);
  return { adminToken: t };
};
Core.prototype.requireAdmin = function (p) {
  if (!p.adminToken || this.s.cacheGet('adm_' + p.adminToken) !== '1') throw err('admin_expired', '교수 로그인이 만료되었습니다. 다시 로그인해 주세요.');
};
Core.prototype.bankStats = function () {
  var by = {};
  function add(u, t) { if (!by[u]) by[u] = { mc: 0, short: 0, essay: 0, imyong: 0, orig: 0 }; by[u][t]++; }
  this.bank.questions.forEach(function (q) { add(q.unit, q.type); });
  var self = this;
  (this.bank.imyong || []).forEach(function (q) {
    var u = q.unit;
    if (!u) { var pg = (q.lecturePages || [])[0]; for (var i = self.outline.length - 1; i >= 0; i--) { if ((self.outline[i].pages || []).indexOf(pg) >= 0) { u = self.outline[i].id; break; } } }
    if (u) add(u, 'imyong');
  });
  (this.bank.orig || []).forEach(function (q) { if (q.unit) add(q.unit, 'orig'); });
  return { byUnit: by, total: this.bank.questions.length, imyong: (this.bank.imyong || []).length, orig: (this.bank.orig || []).length, bankVersion: this.bank.version || '' };
};
Core.prototype.attemptSummary = function (s, a) {
  var sc = this.score(s, a);
  return {
    no: a.no, name: a.name, status: a.status, endReason: a.endReason || null, startedAt: a.startedAt,
    submittedAt: a.submittedAt || null, updatedAt: a.updatedAt, violations: a.violations, device: a.device,
    score: a.status === 'in_progress' ? null : (a.status === 'terminated' ? 0 : sc.total), pending: sc.pending,
    answered: Object.keys(a.answers || {}).filter(function (k) { return String(a.answers[k]).length; }).length,
    items: sc.items, answers: a.answers, manual: a.manual || {}, order: a.order, optOrder: a.optOrder
  };
};
Core.prototype.listSessionsAdmin = function () {
  var self = this;
  return {
    sessions: this.s.listSessions().sort(function (a, b) { return (b.createdAt || 0) - (a.createdAt || 0); }).map(function (s) {
      var at = self.s.listAttempts(s.id), done = at.filter(function (a) { return a.status !== 'in_progress'; });
      var scores = done.map(function (a) { return a.status === 'terminated' ? 0 : self.score(s, a).total; });
      return Object.assign(self.publicSession(s), {
        nAttempts: at.length, nDone: done.length, nInProgress: at.length - done.length,
        nTerminated: at.filter(function (a) { return a.status === 'terminated'; }).length,
        nPending: done.filter(function (a) { return a.status === 'submitted' && self.score(s, a).pending; }).length,
        avg: scores.length ? round1(scores.reduce(function (t, x) { return t + x; }, 0) / scores.length) : null,
        scores: scores
      });
    })
  };
};
Core.prototype.sessionDetail = function (p) {
  var s = this.s.getSession(p.id); if (!s) throw err('not_found', '회기가 없습니다.');
  var self = this;
  return { session: s, attempts: this.s.listAttempts(s.id).map(function (a) { return self.attemptSummary(s, a); }), serverNow: this.s.now() };
};
Core.prototype.setManual = function (p) {
  var s = this.s.getSession(p.sid), a = this.s.getAttempt(p.sid, normNo(p.studentNo));
  if (!s || !a) throw err('not_found', '응시 기록이 없습니다.');
  a.manual = a.manual || {};
  if (p.value === null || p.value === undefined || p.value === '') delete a.manual[p.qid];
  else a.manual[p.qid] = Math.max(0, Math.min(1, Number(p.value)));
  if (a.status !== 'in_progress') { var sc = this.score(s, a); a.score = sc.total; a.pending = sc.pending; }
  a.updatedAt = this.s.now();
  this.s.putAttempt(a);
  return { attempt: this.attemptSummary(s, a) };
};
Core.prototype.resetAttempt = function (p) {
  var no = normNo(p.studentNo);
  this.s.deleteAttempt(p.sid, no);
  this.s.log([this.s.now(), p.sid, no, 'reset', '교수 재응시 허용']);
  return { ok: true };
};
Core.prototype.forgive = function (p) {
  var s = this.s.getSession(p.sid), a = this.s.getAttempt(p.sid, normNo(p.studentNo));
  if (!s || !a) throw err('not_found', '응시 기록이 없습니다.');
  if (!a.violations.length) return { attempt: this.attemptSummary(s, a) };
  var v = a.violations.pop();
  a.forgiven = (a.forgiven || []).concat([Object.assign(v, { forgivenAt: this.s.now() })]);
  if (a.status === 'terminated' && a.violations.length < VIOLATION_LIMIT) {
    a.status = 'in_progress'; delete a.endReason; delete a.submittedAt; a.score = null;
  }
  a.updatedAt = this.s.now();
  this.s.putAttempt(a);
  this.s.log([this.s.now(), s.id, a.no, 'forgive', v.kind]);
  return { attempt: this.attemptSummary(s, a) };
};
Core.prototype.gradebook = function () {
  var self = this, sessions = this.s.listSessions().filter(function (s) { return s.status !== 'draft'; })
    .sort(function (a, b) { return (a.openedAt || a.createdAt) - (b.openedAt || b.createdAt); });
  var students = {};
  var cols = sessions.map(function (s) {
    var at = self.s.listAttempts(s.id), qstat = {};
    s.questions.forEach(function (q) { qstat[q.qid] = { n: 0, sum: 0 }; });
    var scores = [];
    at.forEach(function (a) {
      if (a.status === 'in_progress') return;
      var sc = self.score(s, a), tot = a.status === 'terminated' ? 0 : sc.total;
      scores.push(tot);
      if (!students[a.no]) students[a.no] = { no: a.no, name: a.name, scores: {} };
      students[a.no].scores[s.id] = tot;
      if (a.status !== 'terminated') s.questions.forEach(function (q) { qstat[q.qid].n++; qstat[q.qid].sum += (sc.items[q.qid] || { frac: 0 }).frac; });
    });
    return {
      id: s.id, title: s.title, at: s.openedAt || s.createdAt, scores: scores,
      avg: scores.length ? round1(scores.reduce(function (t, x) { return t + x; }, 0) / scores.length) : null,
      items: s.questions.map(function (q) { var st = qstat[q.qid]; return { qid: q.qid, type: q.type, kind: q.kind, code: q.code || null, stem: q.stem.slice(0, 60), rate: st.n ? round1(st.sum / st.n * 100) : null }; })
    };
  });
  return { sessions: cols, students: Object.keys(students).sort().map(function (k) { return students[k]; }) };
};

/* ---------- 요청 처리 ---------- */
var PUBLIC_ACTIONS = { ping: 1, listOpen: 1, enter: 1, save: 1, violation: 1, submit: 1, myHistory: 1, myResult: 1, adminLogin: 1 };
Core.prototype.handle = function (req) {
  var a = req.action;
  try {
    if (!PUBLIC_ACTIONS[a]) this.requireAdmin(req);
    var r;
    switch (a) {
      case 'ping': r = { version: CORE_VERSION, bank: this.bank.version || '' }; break;
      case 'listOpen': r = this.listOpen(); break;
      case 'enter': r = this.enter(req); break;
      case 'save': r = this.save(req); break;
      case 'violation': r = this.violation(req); break;
      case 'submit': r = this.submit(req); break;
      case 'myHistory': r = this.myHistory(req); break;
      case 'adminLogin': r = this.adminLogin(req); break;
      case 'bankStats': r = this.bankStats(); break;
      case 'generate': r = this.generate(req); break;
      case 'regenOne': r = this.regenOne(req); break;
      case 'createSession': r = this.createSession(req); break;
      case 'updateSession': r = this.updateSession(req); break;
      case 'deleteSession': r = this.deleteSession(req); break;
      case 'listSessions': r = this.listSessionsAdmin(); break;
      case 'sessionDetail': r = this.sessionDetail(req); break;
      case 'setManual': r = this.setManual(req); break;
      case 'resetAttempt': r = this.resetAttempt(req); break;
      case 'forgive': r = this.forgive(req); break;
      case 'gradebook': r = this.gradebook(); break;
      case 'getRoster': r = { roster: this.getRoster() }; break;
      case 'setRoster': r = this.setRoster(req); break;
      case 'bankList': r = { questions: this.bank.questions, imyong: this.bank.imyong || [], orig: this.bank.orig || [] }; break;
      case 'myResult': r = this.myResult(req); break;
      default: throw err('bad_action', '알 수 없는 요청');
    }
    r.ok = true; return r;
  } catch (e) {
    return { ok: false, code: e.code || 'error', message: e.code ? e.message : ('서버 오류: ' + e.message) };
  }
};

if (typeof module !== 'undefined') module.exports = { Core: Core, normAns: normAns, normNo: normNo, VIOLATION_LIMIT: VIOLATION_LIMIT };
