#!/usr/bin/env python3
"""장별 은행을 합쳐 배포 파일을 만든다.
site/  : GitHub Pages에 올릴 학생·교수 화면(정답 없음)
server/Code.gs : Apps Script에 붙일 서버 코드(정답 포함)
test/  : 로컬 시험용(체험 서버 포함)
"""
import json, os, re, shutil, hashlib, sys, datetime
ROOT = os.path.dirname(os.path.abspath(__file__))
BANK = '/tmp/claude-0/-home-claude/3f0c5b8c-3216-5a2c-b4d7-bfee62afdd29/scratchpad/bank'
VERSION = '1.3.1'

outline, questions, chapters = [], [], []
for n in range(1, 7):
    d = json.load(open(f'{BANK}/ch{n}.json', encoding='utf-8'))
    ch = d['chapter']; cid = ch['id']
    pages = []
    for o in d['outline']:
        for p in o.get('pages', []):
            if p not in pages: pages.append(p)
    outline.append({'id': cid, 'ch': cid, 'level': 0, 'num': ch['num'], 'title': ch['title'], 'part': ch.get('part', ''), 'pages': pages})
    for o in d['outline']:
        outline.append({'id': o['id'], 'ch': cid, 'level': o['level'], 'num': o.get('num', ''), 'title': o['title'], 'pages': o.get('pages', [])})
    for q in d['questions']:
        q = dict(q); q.setdefault('unit', cid); questions.append(q)

TP = f'{BANK}/trend.json'
if os.path.exists(TP):
    tr = json.load(open(TP, encoding='utf-8'))
    for o in outline:
        x = tr.get('nodes', {}).get(o['id']) or (tr.get('chapters', {}).get(o['id']) if o['level'] == 0 else None)
        if x:
            o['imp'] = {k: x[k] for k in ('grade', 'count', 'subtotal', 'recent', 'latest', 'trend', 'codes') if k in x and x[k] not in (None, '', [])}
    json.dump(tr.get('outside', []), open(f'{ROOT}/dist/outside.json', 'w', encoding='utf-8'), ensure_ascii=False)
ids = {o['id'] for o in outline}
assert len(ids) == len(outline), '목차 id 중복'
seen = set()
for q in questions:
    assert q['unit'] in ids, ('unit 없음', q['id'])
    assert q['id'] not in seen, ('문항 id 중복', q['id']); seen.add(q['id'])
    if q['type'] == 'mc': assert 0 <= q['answer'] < len(q['options']) and len(set(q['options'])) == len(q['options']), q['id']
    if q['type'] == 'short': assert q.get('accept'), q['id']
    if q['type'] == 'essay': assert q.get('keyPoints'), q['id']

imyong = []
ip = f'{BANK}/imyong.json'
if os.path.exists(ip):
    UNVERIFIED = {'im-2013중등39-1', 'im-2026유아A7-1', 'im-2021중등B8-2', 'im-2009초등12-1'}  # 공식 정답을 글자로 확인하지 못한 항목은 뺀다
    for q in json.load(open(ip, encoding='utf-8'))['items']:
        if q['id'] in UNVERIFIED: continue
        q = dict(q); q['kind'] = 'imyong'
        if q['type'] == 'mc': assert 0 <= q['answer'] < len(q['options']), q['id']
        if q['type'] == 'short': assert q.get('accept'), q['id']
        assert q['id'] not in seen, ('id 중복', q['id']); seen.add(q['id'])
        # 강의자료 쪽 → 가장 깊은 목차 노드
        unit = None
        for pg in q.get('lecturePages', []):
            best = None
            for o in outline:
                if pg in o['pages'] and (q.get('chapter') in (None, o['ch'])):
                    if best is None or o['level'] >= best['level']: best = o
            if best: unit = best['id']; break
        q['unit'] = unit
        imyong.append(q)

orig = []
op = f'{BANK}/orig.json'
if os.path.exists(op):
    for q in json.load(open(op, encoding='utf-8'))['items']:
        q = dict(q); q['kind'] = 'orig'; q['type'] = 'essay'
        assert q.get('keyPoints') and q.get('stem'), q['id']
        assert q['id'] not in seen, ('id 중복', q['id']); seen.add(q['id'])
        if q.get('unit') not in ids:
            q['unit'] = None
            for pg in q.get('lecturePages', []):
                best = None
                for o in outline:
                    if pg in o['pages'] and (best is None or o['level'] >= best['level']): best = o
                if best: q['unit'] = best['id']; break
        orig.append(q)
stamp = hashlib.sha256(json.dumps([questions, imyong, orig], ensure_ascii=False, sort_keys=True).encode()).hexdigest()[:8]
bank = {'version': f'{VERSION}-{stamp}', 'questions': questions, 'imyong': imyong, 'orig': orig}
counts = {}
for q in questions: counts[q['type']] = counts.get(q['type'], 0) + 1
print('목차', len(outline), '문항', len(questions), counts, '기출 변형', len(imyong), '기출 원문', len(orig), '미배정', sum(1 for q in imyong if not q['unit']))

outside = json.load(open(f'{ROOT}/dist/outside.json', encoding='utf-8')) if os.path.exists(f'{ROOT}/dist/outside.json') else []
outline_js = '/* 강의자료 목차와 임용 출제 경향(정답 없음) */\nwindow.OUTLINE=' + json.dumps(outline, ensure_ascii=False, separators=(',', ':')) + ';\nwindow.TREND_OUTSIDE=' + json.dumps(outside, ensure_ascii=False, separators=(',', ':')) + ';\n'
core = open(f'{ROOT}/server/core.js', encoding='utf-8').read()
core_gs = core.split("if (typeof module !== 'undefined')")[0]
gas = open(f'{ROOT}/server/gas.js', encoding='utf-8').read()
data = 'var BANK = ' + json.dumps(bank, ensure_ascii=False, separators=(',', ':')) + ';\nvar OUTLINE = ' + json.dumps(outline, ensure_ascii=False, separators=(',', ':')) + ';\n'
os.makedirs(f'{ROOT}/dist/server', exist_ok=True)
code_gs = '/* 의사소통장애 퀴즈 기록 서버 v' + VERSION + ' (문항은행 ' + bank['version'] + ') */\n// 편집기 실행 목록 맨 위(눌러도 안전): 부하 점검용 숨김 회기 만들기. 제출 마무리는 교수 화면 버튼 또는 runFinalizeAll\nfunction runLoadTestPrepare() { loadTestPrepare(); }\nfunction runSetup() { setup(); }\nfunction runFinalizeAll() { finalizeAllSessions(); }\n' + core_gs + '\n' + gas + '\n' + data
open(f'{ROOT}/dist/server/Code.gs', 'w', encoding='utf-8').write(code_gs)

def copy_web(dst, demo):
    if os.path.exists(dst): shutil.rmtree(dst)
    os.makedirs(dst)
    for f in ['index.html', 'admin.html', 'app.css', 'common.js', 'student.js', 'admin.js']:
        shutil.copy(f'{ROOT}/web/{f}', f'{dst}/{f}')
    open(f'{dst}/outline.js', 'w', encoding='utf-8').write(outline_js)
    cfg = sys.argv[1] if len(sys.argv) > 1 and not demo else ''
    open(f'{dst}/config.js', 'w', encoding='utf-8').write('window.QUIZ_CONFIG={api:' + json.dumps(cfg) + '};\n')
    open(f'{dst}/.nojekyll', 'w').write('')
    if demo:
        demo_js = core_gs + '\n' + data + open(f'{ROOT}/server/demo_store.js', encoding='utf-8').read()
        open(f'{dst}/demo.js', 'w', encoding='utf-8').write(demo_js)
        for f in ['index.html', 'admin.html']:
            p = f'{dst}/{f}'; t = open(p, encoding='utf-8').read()
            t = t.replace('<script src="common.js', '<script src="demo.js"></script>\n<script src="common.js')
            open(p, 'w', encoding='utf-8').write(t)

copy_web(f'{ROOT}/dist/site', False)
copy_web(f'{ROOT}/dist/test', True)
json.dump(bank, open(f'{ROOT}/dist/bank.json', 'w', encoding='utf-8'), ensure_ascii=False, indent=1)
# 정답 유출 점검: 배포 화면 파일에 정답 필드가 없어야 함
for f in os.listdir(f'{ROOT}/dist/site'):
    t = open(f'{ROOT}/dist/site/{f}', encoding='utf-8', errors='ignore').read()
    assert '"accept"' not in t and '"keyPoints"' not in t and '"answer":' not in t, ('정답 유출', f)
print('Code.gs', len(code_gs.encode()) // 1024, 'KB')
