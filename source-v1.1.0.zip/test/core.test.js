// 서버 핵심 로직 시험: node test/core.test.js
const fs = require('fs'), path = require('path'), assert = require('assert');
const { Core } = require('../server/core.js');
const bank = JSON.parse(fs.readFileSync(path.join(__dirname, '../dist/bank.json'), 'utf8'));
const outline = JSON.parse(fs.readFileSync(path.join(__dirname, '../dist/site/outline.js'), 'utf8').match(/window.OUTLINE=(.*?);\n/s)[1]);
let T = 1_700_000_000_000;
function mkStore() {
  const S = {}, A = {}, P = { ADMIN_PW: 'pw-test' }, C = {}, L = [];
  return {
    L, now: () => T, random: Math.random, sha256: s => 'h' + s,
    cacheGet: k => C[k] || null, cachePut: (k, v) => { C[k] = v; },
    getProp: k => P[k] || null, setProp: (k, v) => { P[k] = v; }, log: r => L.push(r),
    listSessions: () => Object.values(S).map(x => JSON.parse(JSON.stringify(x))), getSession: id => S[id] ? JSON.parse(JSON.stringify(S[id])) : null,
    putSession: s => { S[s.id] = JSON.parse(JSON.stringify(s)); }, deleteSession: id => { delete S[id]; },
    getAttempt: (sid, no) => A[sid + '|' + no] ? JSON.parse(JSON.stringify(A[sid + '|' + no])) : null, putAttempt: a => { A[a.sid + '|' + a.no] = JSON.parse(JSON.stringify(a)); },
    deleteAttempt: (sid, no) => { delete A[sid + '|' + no]; },
    listAttempts: sid => Object.values(A).filter(a => a.sid === sid).map(x => JSON.parse(JSON.stringify(x))),
    listAttemptsByStudent: no => Object.values(A).filter(a => a.no === no).map(x => JSON.parse(JSON.stringify(x)))
  };
}
const st = mkStore(), core = () => new Core(st, bank, outline), call = r => core().handle(r);
let n = 0; function ok(c, m) { assert.ok(c, m); n++; }

// 교수 로그인
ok(!call({ action: 'adminLogin', pw: 'x' }).ok, '틀린 비번 거부');
const adm = call({ action: 'adminLogin', pw: 'pw-test' }).adminToken; ok(adm, '로그인');
ok(call({ action: 'generate', range: {}, counts: { mc: 5 } }).code === 'admin_expired', '토큰 없이 교수 기능 거부');

// 범위: 제1장 처음 ~ 제2장 4. 신경기관 4) 대뇌 (4) 실어증
const R = { start: null, end: 'c2-4-4-4' };
const units = core().rangeUnits(R);
ok(units['c1'] && units['c2-4-4-4'] && !units['c2-5'] && !units['c3'], '범위 단원');
for (let k = 0; k < 20; k++) {
  const g = call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 4, short: 2, essay: 1, imyong: 1 } });
  ok(g.ok && g.questions.length === 8, '8문항 생성 ' + JSON.stringify(g.shortage));
  g.questions.forEach(q => ok(q.kind === 'imyong' || units[q.unit], '범위 밖 문항 ' + q.bankId));
}
ok(!call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 11 } }).ok, '11문항 거부');
ok(!call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 4 } }).ok, '4문항 거부');
// 범위 끝 노드 하위 포함: 제2장 끝까지
const u2 = core().rangeUnits({ start: 'c2', end: 'c2' }); ok(u2['c2-4-4-4'] && !u2['c1'] && !u2['c3'], '장 하나');

const g = call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 5, short: 2, essay: 1, imyong: 0 } });
const cs = call({ action: 'createSession', adminToken: adm, title: '시험1', range: R, rangeLabel: 'L', questions: g.questions, timeLimit: 10, showResult: 'immediate', shuffle: true, status: 'open' });
ok(cs.ok, '회기 생성'); const sid = cs.session.id;
const open = call({ action: 'listOpen' }); ok(open.sessions.length === 1 && !JSON.stringify(open).includes('"answer"'), '열린 목록, 정답 없음');

// 학생 A: 정상 제출
let e = call({ action: 'enter', sid, studentNo: '2024a001', name: '김가나', device: 'test' });
ok(e.ok && e.status === 'in_progress' && e.questions.length === 8, '입장');
const leak = JSON.stringify(e); ok(!leak.includes('"answer"') && !leak.includes('accept') && !leak.includes('keyPoints') && !leak.includes('explain'), '학생에게 정답 없음');
const S = st.getSession(sid);
// 정답 만들기 (화면 번호로 변환)
const att = st.getAttempt(sid, '2024A001');
const ans = {};
e.questions.forEach(v => {
  const q = S.questions.find(x => x.qid === v.qid);
  if (q.type === 'mc') { const perm = att.optOrder[q.qid] || q.options.map((_, i) => i); ans[q.qid] = perm.indexOf(q.answer); }
  else if (q.type === 'short') ans[q.qid] = ' ' + q.accept[0] + ' ';
  else ans[q.qid] = q.keyPoints.map(k => k.keywords[0]).join(' 그리고 ');
});
ok(call({ action: 'save', sid, studentNo: '2024A001', token: e.token, answers: ans }).ok, '저장');
ok(!call({ action: 'save', sid, studentNo: '2024A001', token: 'bad', answers: ans }).ok, '틀린 토큰 거부');
// 이탈 1회 (away → return 같은 번호) = 1회
let v = call({ action: 'violation', sid, studentNo: '2024A001', token: e.token, eventId: 'e1', kind: 'hidden', phase: 'away' });
v = call({ action: 'violation', sid, studentNo: '2024A001', token: e.token, eventId: 'e1', kind: 'hidden', phase: 'return' });
ok(v.violations === 1 && v.status === 'in_progress', '이탈 1회 경고');
T += 60000;
let sub = call({ action: 'submit', sid, studentNo: '2024A001', token: e.token, answers: {} });
ok(sub.ok && sub.status === 'submitted' && sub.result.score === 100, '만점 ' + sub.result.score);
ok(sub.result.items.length === 8 && sub.result.items.every(i => i.frac === 1), '문항별 결과');
// 제출 뒤 재입장 = 결과만, 이탈 증가 없음
e = call({ action: 'enter', sid, studentNo: '2024A001', name: '김가나' }); ok(e.status === 'submitted' && e.violations === 1, '제출 뒤 재입장');
ok(!call({ action: 'enter', sid, studentNo: '2024A001', name: '박다라' }).ok, '다른 이름 거부');

// 학생 B: 이탈 2회 → 즉시 종료 0점
e = call({ action: 'enter', sid, studentNo: '2024A002', name: '이마바' });
call({ action: 'violation', sid, studentNo: '2024A002', token: e.token, eventId: 'b1', kind: 'blur', phase: 'return' });
v = call({ action: 'violation', sid, studentNo: '2024A002', token: e.token, eventId: 'b2', kind: 'hidden', phase: 'away' });
ok(v.status === 'terminated' && v.violations === 2 && v.result.score === 0, '2회 종료 0점');
ok(!call({ action: 'violation', sid, studentNo: '2024A002', token: e.token, eventId: 'b3', kind: 'hidden' }).added, '종료 뒤 추가 없음');
// 교수 이탈 1회 취소 → 다시 응시 중
let f = call({ action: 'forgive', adminToken: adm, sid, studentNo: '2024A002' });
ok(f.attempt.status === 'in_progress' && f.attempt.violations.length === 1, '이탈 취소 복구');

// 학생 C: 앱을 닫음(away만 전송) → 재입장: 같은 이탈로 1회
e = call({ action: 'enter', sid, studentNo: '2024A003', name: '최사아' });
call({ action: 'violation', sid, studentNo: '2024A003', token: e.token, eventId: 'c1', kind: 'hidden', phase: 'away' });
e = call({ action: 'enter', sid, studentNo: '2024A003', name: '최사아' });
ok(e.status === 'in_progress' && e.violations === 1 && e.reentered, '닫고 재입장 1회');
// 아무 신호 없이 재입장(전송 실패) → reenter로 2회 → 종료
e = call({ action: 'enter', sid, studentNo: '2024A003', name: '최사아' });
ok(e.status === 'terminated' && e.violations === 2 && e.result.score === 0, '재입장 2회째 종료');

// 학생 D: 시간 초과 뒤 제출
e = call({ action: 'enter', sid, studentNo: '2024A004', name: '정자차' });
T += 13 * 60000;
sub = call({ action: 'submit', sid, studentNo: '2024A004', token: e.token, answers: {} });
ok(sub.status === 'submitted' && sub.result.score === 0, '시간 초과 제출(무응답 0점)');
// 단답형 채점 관용
const sq = { qid: 'x', type: 'short', accept: ['브로카 실어증'] };
ok(core().gradeOne(sq, '브로카실어증').frac === 1 && core().gradeOne(sq, '브로카 실어증입니다.').frac === 1 && core().gradeOne(sq, '베르니케').frac === 0, '단답 정규화');

// 교수 수동 채점
const det = call({ action: 'sessionDetail', adminToken: adm, id: sid }); ok(det.attempts.length === 4, '상세');
const ess = S.questions.find(q => q.type === 'essay');
let m = call({ action: 'setManual', adminToken: adm, sid, studentNo: '2024A001', qid: ess.qid, value: 0.5 });
ok(m.attempt.score === 93.8 && m.attempt.pending === 0, '서술형 수동 ' + m.attempt.score);
// 기록·성적
const hist = call({ action: 'myHistory', studentNo: '2024a001', name: '김가나' });
ok(hist.history.length === 1 && hist.history[0].score === 93.8, '내 점수');
const gb = call({ action: 'gradebook', adminToken: adm }); ok(gb.sessions[0].items.length === 8 && gb.students.length >= 3, '성적표');
// 결과 비공개 회기
const cs2 = call({ action: 'createSession', adminToken: adm, title: '시험2', questions: g.questions, showResult: 'after', status: 'open' });
e = call({ action: 'enter', sid: cs2.session.id, studentNo: '2024A001', name: '김가나' });
sub = call({ action: 'submit', sid: cs2.session.id, studentNo: '2024A001', token: e.token, answers: {} });
ok(!sub.result.released && sub.result.score === undefined && !sub.result.items, '비공개면 점수 숨김');
ok(call({ action: 'myHistory', studentNo: '2024A001', name: '김가나' }).history[1].score === undefined, '기록도 숨김');
// 명단
call({ action: 'setRoster', adminToken: adm, roster: [{ no: '2024a009', name: '한 하늘' }] });
ok(call({ action: 'enter', sid, studentNo: '2024A010', name: 'x' }).code === 'not_in_roster', '명단 밖 거부');
ok(call({ action: 'enter', sid, studentNo: '2024A009', name: '한하늘' }).ok, '명단 안 입장');
// 이전 회기 문항 빼기
const used = core().usedIds(); const g3 = call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 5 }, excludeUsed: true });
ok(g3.questions.every(q => !used[q.bankId]), '이전 문항 제외');
// 전 범위 여러 조합
['c1', 'c3', 'c4', 'c5', 'c6'].forEach(c => { const r = call({ action: 'generate', adminToken: adm, range: { start: c, end: c }, counts: { mc: 4, short: 3, essay: 2, imyong: 1 } }); ok(r.ok, c); });
console.log('통과', n, '항목');
