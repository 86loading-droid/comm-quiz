/* Apps Script 어댑터 — 구글 시트에 회기·응시 기록을 저장한다.
 * 시트: sessions(id, json, updatedAt) / attempts(key, sid, no, name, status, score, json, updatedAt, draft) / log(시각, 회기, 학번, 종류, 내용)
 * 스크립트 속성: ADMIN_PW(교수 비밀번호, 교수님이 직접 입력), SHEET_ID(첫 실행 때 자동 생성)
 *
 * 동시 접속 대비(v1.3.0)
 *  - 자동 저장(save)은 서버 잠금을 기다리지 않는다. 자기 응시 행의 draft 칸(9열)에만 쓴다.
 *  - 제출(submit)은 잠금을 12초 안에 얻으면 바로 채점, 못 얻으면 draft 칸에 「제출 접수」로 남기고 학생에게 접수 완료를 알린다.
 *    접수분은 다음 잠금 요청·교수 화면 열람·「제출 마무리」에서 학생이 제출한 시각으로 채점된다.
 *  - 응시 행은 시트 전체를 읽지 않고 TextFinder로 그 행만 찾는다. 회기는 캐시에 둔다.
 */
function sheetBook_() {
  if (GAS_MEMO_.$book) return GAS_MEMO_.$book;
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('SHEET_ID');
  if (id) { try { return (GAS_MEMO_.$book = SpreadsheetApp.openById(id)); } catch (e) { } }
  var ss = SpreadsheetApp.create('의사소통장애 퀴즈 기록');
  props.setProperty('SHEET_ID', ss.getId());
  return (GAS_MEMO_.$book = ss);
}
function sheet_(name, header) {
  var mk = '$sh_' + name;
  if (GAS_MEMO_[mk]) return GAS_MEMO_[mk];
  var ss = sheetBook_(), sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, header.length).setValues([header]);
    sh.setFrozenRows(1);
    var d = ss.getSheetByName('Sheet1') || ss.getSheetByName('시트1');
    if (d && ss.getSheets().length > 1) ss.deleteSheet(d);
  }
  return (GAS_MEMO_[mk] = sh);
}
var GAS_MEMO_ = {};
function rows_(name, header) {
  if (GAS_MEMO_[name]) return GAS_MEMO_[name];
  var sh = sheet_(name, header), n = sh.getLastRow();
  var vals = n > 1 ? sh.getRange(2, 1, n - 1, header.length).getValues() : [];
  GAS_MEMO_[name] = { sh: sh, vals: vals };
  return GAS_MEMO_[name];
}
var SESS_H_ = ['id', 'json', 'updatedAt'];
var ATT_H_ = ['key', 'sid', 'no', 'name', 'status', 'score', 'json', 'updatedAt', 'draft'];
var NC_ = ATT_H_.length;

function attSheet_() { return sheet_('attempts', ATT_H_); }
// col열에서 text와 똑같은 칸의 행 번호들(머리글 제외)
function findRows_(sh, col, text, whole) {
  var n = sh.getLastRow(); if (n < 2) return [];
  var f = sh.getRange(2, col, n - 1, 1).createTextFinder(String(text)).matchCase(true);
  if (whole !== false) f = f.matchEntireCell(true);
  return f.findAll().map(function (r) { return r.getRow(); });
}
function parseAtt_(row) {
  var a = JSON.parse(row[6]);
  if (row[8]) { try { Object.defineProperty(a, '$draft', { value: JSON.parse(row[8]), enumerable: false, configurable: true, writable: true }); } catch (e) { } }
  return a;
}
function attRow_(key) {   // 응시 행 번호(없으면 0)
  var m = GAS_MEMO_.attempts;
  if (m) { for (var i = 0; i < m.vals.length; i++) if (m.vals[i][0] === key) return i + 2; return 0; }
  var rm = GAS_MEMO_.$rows || (GAS_MEMO_.$rows = {});
  if (rm[key]) return rm[key];
  var r = findRows_(attSheet_(), 1, key);
  if (r.length) { rm[key] = r[0]; try { CacheService.getScriptCache().put('r:' + key, String(r[0]), 21600); } catch (e) { } }
  return r.length ? r[0] : 0;
}
function readRows_(sh, rows) {   // 흩어진 행을 한 덩어리로 읽어 해당 행만 돌려준다
  if (!rows.length) return [];
  var lo = Math.min.apply(null, rows), hi = Math.max.apply(null, rows);
  if (hi - lo > 400) return rows.map(function (r) { return sh.getRange(r, 1, 1, NC_).getValues()[0]; });
  var block = sh.getRange(lo, 1, hi - lo + 1, NC_).getValues();
  return rows.map(function (r) { return block[r - lo]; });
}

var GasStore = {
  now: function () { return Date.now(); },
  random: function () { return Math.random(); },
  sha256: function (str) {
    var b = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, str, Utilities.Charset.UTF_8);
    return b.map(function (x) { return ('0' + (x & 255).toString(16)).slice(-2); }).join('');
  },
  cacheGet: function (k) { return CacheService.getScriptCache().get(k); },
  cachePut: function (k, v, sec) { CacheService.getScriptCache().put(k, v, sec); },
  getProp: function (k) { return PropertiesService.getScriptProperties().getProperty(k); },
  setProp: function (k, v) { PropertiesService.getScriptProperties().setProperty(k, v); },
  log: function (row) {
    var sh = sheet_('log', ['시각', '회기', '학번', '종류', '내용']);
    row[0] = new Date(row[0]);
    sh.appendRow(row);
  },
  listSessions: function () { return rows_('sessions', SESS_H_).vals.map(function (r) { return JSON.parse(r[1]); }); },
  getSession: function (id) {
    var c = null; try { c = CacheService.getScriptCache().get('sess:' + id); } catch (e) { }
    if (c) return JSON.parse(c);
    var v = rows_('sessions', SESS_H_).vals;
    for (var i = 0; i < v.length; i++) if (v[i][0] === id) {
      try { if (String(v[i][1]).length < 90000) CacheService.getScriptCache().put('sess:' + id, v[i][1], 21600); } catch (e) { }
      return JSON.parse(v[i][1]);
    }
    return null;
  },
  putSession: function (s) {
    var m = rows_('sessions', SESS_H_), json = JSON.stringify(s);
    try { CacheService.getScriptCache().remove('listOpen'); } catch (e) { }
    try { var c = CacheService.getScriptCache(); if (json.length < 90000) c.put('sess:' + s.id, json, 21600); else c.remove('sess:' + s.id); } catch (e) { }
    for (var i = 0; i < m.vals.length; i++) if (m.vals[i][0] === s.id) {
      m.sh.getRange(i + 2, 1, 1, 3).setValues([[s.id, json, new Date()]]); m.vals[i] = [s.id, json, new Date()]; return;
    }
    m.sh.appendRow([s.id, json, new Date()]); m.vals.push([s.id, json, new Date()]);
  },
  deleteSession: function (id) {
    try { CacheService.getScriptCache().removeAll(['sess:' + id, 'listOpen']); } catch (e) { }
    var m = rows_('sessions', SESS_H_);
    for (var i = m.vals.length - 1; i >= 0; i--) if (m.vals[i][0] === id) { m.sh.deleteRow(i + 2); m.vals.splice(i, 1); }
  },
  getAttempt: function (sid, no) {
    var key = sid + '|' + no, m = GAS_MEMO_.attempts;
    if (m) { for (var i = 0; i < m.vals.length; i++) if (m.vals[i][0] === key) return parseAtt_(m.vals[i]); return null; }
    // 행 번호 캐시: 그 행을 읽어 열쇠가 맞을 때만 쓴다(행이 지워져 밀렸으면 다시 찾는다)
    var c = null; try { c = Number(CacheService.getScriptCache().get('r:' + key)) || 0; } catch (e) { }
    if (c) {
      var rowc = attSheet_().getRange(c, 1, 1, NC_).getValues()[0];
      if (rowc[0] === key) { (GAS_MEMO_.$rows || (GAS_MEMO_.$rows = {}))[key] = c; return parseAtt_(rowc); }
    }
    var r = attRow_(key); if (!r) return null;
    var row = attSheet_().getRange(r, 1, 1, NC_).getValues()[0];
    return row[0] === key ? parseAtt_(row) : null;
  },
  putAttempt: function (a) {
    var sh = attSheet_(), key = a.sid + '|' + a.no, json = JSON.stringify(a);
    var row = [key, a.sid, a.no, a.name, a.status, a.score == null ? '' : a.score, json, new Date(), ''];
    var r = attRow_(key);
    if (r) {
      if (a.status === 'in_progress') {
        // 이 요청이 읽은 뒤 잠금 없이 들어온 더 새로운 저장·제출 접수는 지우지 않는다
        var cur = sh.getRange(r, 9).getValue();
        if (cur) { try { var d = JSON.parse(cur); if ((d.at || 0) > (a.updatedAt || 0) || d.submit) row[8] = cur; } catch (e) { } }
      }
      sh.getRange(r, 1, 1, NC_).setValues([row]);
      if (GAS_MEMO_.attempts) GAS_MEMO_.attempts.vals[r - 2] = row;
      return;
    }
    sh.appendRow(row);
    if (GAS_MEMO_.attempts) GAS_MEMO_.attempts.vals.push(row);
  },
  deleteAttempt: function (sid, no) {
    var key = sid + '|' + no, r = attRow_(key); if (!r) return;
    attSheet_().deleteRow(r);
    if (GAS_MEMO_.attempts) GAS_MEMO_.attempts.vals.splice(r - 2, 1);
  },
  listAttempts: function (sid) {
    if (GAS_MEMO_.attempts) return GAS_MEMO_.attempts.vals.filter(function (r) { return r[1] === sid; }).map(parseAtt_);
    var sh = attSheet_();
    return readRows_(sh, findRows_(sh, 2, sid)).filter(function (r) { return r[1] === sid; }).map(parseAtt_);
  },
  listAttemptsByStudent: function (no) {
    var sh = attSheet_();
    return readRows_(sh, findRows_(sh, 3, no)).filter(function (r) { return String(r[2]) === no; }).map(parseAtt_);
  },
  // 같은 학번이 앞서 쓴 이름들(학번 열·이름 열만 읽는다)
  namesByStudent: function (no) {
    var sh = attSheet_(), n = sh.getLastRow(); if (n < 2) return [];
    return sh.getRange(2, 3, n - 1, 2).getValues().filter(function (r) { return String(r[0]) === no; }).map(function (r) { return r[1]; });
  },
  // 잠금 없이 이 학생 행의 draft 칸에만 쓴다
  putDraft: function (sid, no, d) {
    var key = sid + '|' + no, r = attRow_(key);
    if (!r) return false;
    attSheet_().getRange(r, 9).setValue(JSON.stringify(d));
    return true;
  },
  // 첫 입장: 확인·준비는 잠금 밖에서 하고, 새 행 자리 잡기(마지막 행 + 1에 쓰기)만 아주 짧게 잠근다.
  // (잠금 없이 appendRow를 동시에 하면 같은 행에 겹쳐 써서 기록이 사라진다 — 2026-10-31 부하 점검에서 확인)
  // 같은 학번이 거의 동시에 두 번 만들면 먼저 생긴 행이 주인(늦은 쪽은 무효 표시)
  addAttempt: function (a) {
    var sh = attSheet_(), key = a.sid + '|' + a.no, lock = LockService.getScriptLock();
    if (!lock.tryLock(20000)) { var e = new Error('접속이 몰려 잠시 기다리는 중입니다. 자동으로 다시 들어갑니다.'); e.code = 'busy'; throw e; }
    try {
      var at = sh.getLastRow() + 1;
      sh.getRange(at, 1, 1, NC_).setValues([[key, a.sid, a.no, a.name, a.status, '', JSON.stringify(a), new Date(), '']]);
      SpreadsheetApp.flush();
    } finally { lock.releaseLock(); }
    var rows = findRows_(sh, 1, key);
    if (rows.length <= 1) { if (rows[0]) (GAS_MEMO_.$rows || (GAS_MEMO_.$rows = {}))[key] = rows[0]; return a; }
    var vals = readRows_(sh, rows), first = parseAtt_(vals[0]);
    if (first.token === a.token) return a;
    for (var i = 1; i < vals.length; i++) {
      try { if (JSON.parse(vals[i][6]).token === a.token) sh.getRange(rows[i], 1, 1, 2).setValues([['dup|' + key, '']]); } catch (e) { }
    }
    return first;
  },
  queuedSubmits: function (force) {
    var c = CacheService.getScriptCache();
    if (!force && !c.get('qpend')) return [];
    var sh = attSheet_(), rows = findRows_(sh, 9, '"submit":true', false);
    if (!rows.length) { c.remove('qpend'); return []; }
    return readRows_(sh, rows).map(function (r) { return { sid: r[1], no: String(r[2]) }; });
  }
};

// 잠금 없이 처리하는 요청(읽기 전용 + 자동 저장)
var NO_LOCK_ = { ping: 1, listOpen: 1, myHistory: 1, myResult: 1, bankStats: 1, listSessions: 1, sessionDetail: 1, gradebook: 1, getRoster: 1, bankList: 1, generate: 1, regenOne: 1, adminLogin: 1, save: 1, enter: 1 };
var ADMIN_VIEW_ = { listSessions: 1, sessionDetail: 1, gradebook: 1 };
var LOCK_WAIT_ = { submit: 3000, violation: 15000, enter: 20000, settle: 8000 };

function handleRequest_(req) {
  var r = handleOnce_(req, false);
  // 입장: 잠금 없이 해 보고, 다시 들어온 경우처럼 기록을 고쳐야 하면 잠금을 잡고 다시 처리
  if (req.action === 'enter' && r && r.code === 'need_lock') r = handleOnce_(req, true);
  return r;
}
function handleOnce_(req, forceLock) {
  GAS_MEMO_ = {};
  var act = req.action, lock = null, core = new Core(GasStore, BANK, OUTLINE);
  if (act === 'listOpen') {   // 학생 첫 화면: 30초 캐시(회기를 바꾸면 바로 지움)
    try { var lc = CacheService.getScriptCache().get('listOpen'); if (lc) return JSON.parse(lc); } catch (e) { }
    var lo = core.handle(req);
    try { if (lo.ok) CacheService.getScriptCache().put('listOpen', JSON.stringify(lo), 30); } catch (e) { }
    return lo;
  }
  if (!NO_LOCK_[act] || forceLock) {
    var l = LockService.getScriptLock();
    if (l.tryLock(LOCK_WAIT_[act] || 20000)) lock = l;
    else if (act === 'submit') { core.locked = false; req.$queue = true; return core.handle(req); }   // 접수만 하고 끝(학생 화면이 잠시 뒤 settle로 채점을 재촉)
    else return { ok: false, code: 'busy', message: '접속이 몰려 잠시 기다리는 중입니다. 자동으로 다시 보냅니다.' };
  } else if (ADMIN_VIEW_[act]) {
    // 교수 화면을 열 때 잠금이 비어 있으면 접수된 제출을 먼저 채점해 둔다
    var l2 = LockService.getScriptLock();
    if (l2.tryLock(1500)) lock = l2;
  }
  core.locked = !!lock;
  try {
    if (lock && ADMIN_VIEW_[act]) { try { core.drainQueue(8000, true); } catch (e) { } GAS_MEMO_ = {}; }
    var r = core.handle(req);
    if (lock && !ADMIN_VIEW_[act]) { try { core.drainQueue(4000); } catch (e) { } }
    return r;
  } finally { if (lock) { try { SpreadsheetApp.flush(); } catch (e) { } lock.releaseLock(); } }   // 쓴 내용을 확정한 뒤에 잠금을 넘긴다
}
function doPost(e) {
  var req = {};
  try { req = JSON.parse(e.postData.contents); } catch (x) { }
  return ContentService.createTextOutput(JSON.stringify(handleRequest_(req))).setMimeType(ContentService.MimeType.JSON);
}
function doGet(e) {
  var req = { action: (e && e.parameter && e.parameter.action) || 'ping' };
  if (req.action !== 'ping' && req.action !== 'listOpen') req = { action: 'ping' };
  return ContentService.createTextOutput(JSON.stringify(handleRequest_(req))).setMimeType(ContentService.MimeType.JSON);
}
// 편집기에서 실행: 부하 점검용 숨김 회기를 만든다(학생 목록·성적표에는 나오지 않음). 실행 기록에 점검 키가 나온다.
function loadTestPrepare() {
  GAS_MEMO_ = {};
  var sh = attSheet_(); if (!sh.getRange(1, 9).getValue()) sh.getRange(1, 9).setValue('draft');
  var core = new Core(GasStore, BANK, OUTLINE), r = core.loadTestPrepare();
  Logger.log('LOADTEST ' + JSON.stringify(r));
}
// 편집기에서 실행: 모든 회기의 응시 중 기록을 마지막 저장 답으로 제출 처리하고 다시 채점한다(교수 화면 버튼과 같은 일)
function finalizeAllSessions() {
  GAS_MEMO_ = {};
  var lock = LockService.getScriptLock(); lock.waitLock(30000);
  try {
    var core = new Core(GasStore, BANK, OUTLINE), out = [];
    GasStore.listSessions().forEach(function (s) {
      if (s.loadTest) return;
      var r = core.finalizeSession({ id: s.id });
      out.push(s.title + ': 제출 마무리 ' + r.finalized.map(function (f) { return f.no + ' ' + f.name + ' ' + f.score + '점'; }).join(', ') + ' / 접수분 채점 ' + r.queuedGraded + '명 / 점수 고침 ' + r.regraded + '건');
    });
    Logger.log(out.join('\n'));
  } finally { SpreadsheetApp.flush(); lock.releaseLock(); }
}
// 편집기에서 한 번 실행: 기록 시트를 만들고 권한을 승인받는다.
function setup() {
  sheet_('sessions', SESS_H_); sheet_('attempts', ATT_H_); sheet_('log', ['시각', '회기', '학번', '종류', '내용']);
  var sh = attSheet_(); if (!sh.getRange(1, 9).getValue()) sh.getRange(1, 9).setValue('draft');
  Logger.log('기록 시트: ' + sheetBook_().getUrl());
}
