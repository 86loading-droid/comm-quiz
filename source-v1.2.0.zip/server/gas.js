/* Apps Script 어댑터 — 구글 시트에 회기·응시 기록을 저장한다.
 * 시트: sessions(id, json, updatedAt) / attempts(key, sid, no, name, status, score, json, updatedAt) / log(시각, 회기, 학번, 종류, 내용)
 * 스크립트 속성: ADMIN_PW(교수 비밀번호, 교수님이 직접 입력), SHEET_ID(첫 실행 때 자동 생성)
 */
function sheetBook_() {
  var props = PropertiesService.getScriptProperties();
  var id = props.getProperty('SHEET_ID');
  if (id) { try { return SpreadsheetApp.openById(id); } catch (e) { } }
  var ss = SpreadsheetApp.create('의사소통장애 퀴즈 기록');
  props.setProperty('SHEET_ID', ss.getId());
  return ss;
}
function sheet_(name, header) {
  var ss = sheetBook_(), sh = ss.getSheetByName(name);
  if (!sh) {
    sh = ss.insertSheet(name);
    sh.getRange(1, 1, 1, header.length).setValues([header]);
    sh.setFrozenRows(1);
    var d = ss.getSheetByName('Sheet1') || ss.getSheetByName('시트1');
    if (d && ss.getSheets().length > 1) ss.deleteSheet(d);
  }
  return sh;
}
var GAS_MEMO_ = {};
function rows_(name, header) {
  if (GAS_MEMO_[name]) return GAS_MEMO_[name];
  var sh = sheet_(name, header), n = sh.getLastRow();
  var vals = n > 1 ? sh.getRange(2, 1, n - 1, header.length).getValues() : [];
  GAS_MEMO_[name] = { sh: sh, vals: vals };
  return GAS_MEMO_[name];
}
var SESS_H_ = ['id', 'json', 'updatedAt'];
var ATT_H_ = ['key', 'sid', 'no', 'name', 'status', 'score', 'json', 'updatedAt'];

var GasStore = {
  now: function () { return Date.now(); },
  random: function () { return Math.random(); },
  sha256: function (str) {
    var b = Utilities.computeDigest(Utilities.DigestAlgorithm.SHA_256, str, Utilities.Charset.UTF_8);
    return b.map(function (x) { return ('0' + (x & 255).toString(16)).slice(-2); }).join('');
  },
  cacheGet: function (k) { return CacheService.getScriptCache().get(k); },
  cachePut: function (k, v, sec) { CacheService.getScriptCache().put(k, v, sec); },
  getProp: function (k) { return PropertiesService.getScriptProperties().getProperty(k); },
  setProp: function (k, v) { PropertiesService.getScriptProperties().setProperty(k, v); },
  log: function (row) {
    var sh = sheet_('log', ['시각', '회기', '학번', '종류', '내용']);
    row[0] = new Date(row[0]);
    sh.appendRow(row);
  },
  listSessions: function () { return rows_('sessions', SESS_H_).vals.map(function (r) { return JSON.parse(r[1]); }); },
  getSession: function (id) {
    var v = rows_('sessions', SESS_H_).vals;
    for (var i = 0; i < v.length; i++) if (v[i][0] === id) return JSON.parse(v[i][1]);
    return null;
  },
  putSession: function (s) {
    var m = rows_('sessions', SESS_H_), json = JSON.stringify(s);
    for (var i = 0; i < m.vals.length; i++) if (m.vals[i][0] === s.id) {
      m.sh.getRange(i + 2, 1, 1, 3).setValues([[s.id, json, new Date()]]); m.vals[i] = [s.id, json, new Date()]; return;
    }
    m.sh.appendRow([s.id, json, new Date()]); m.vals.push([s.id, json, new Date()]);
  },
  deleteSession: function (id) {
    var m = rows_('sessions', SESS_H_);
    for (var i = m.vals.length - 1; i >= 0; i--) if (m.vals[i][0] === id) { m.sh.deleteRow(i + 2); m.vals.splice(i, 1); }
  },
  getAttempt: function (sid, no) {
    var v = rows_('attempts', ATT_H_).vals, key = sid + '|' + no;
    for (var i = 0; i < v.length; i++) if (v[i][0] === key) return JSON.parse(v[i][6]);
    return null;
  },
  putAttempt: function (a) {
    var m = rows_('attempts', ATT_H_), key = a.sid + '|' + a.no, json = JSON.stringify(a);
    var row = [key, a.sid, a.no, a.name, a.status, a.score == null ? '' : a.score, json, new Date()];
    for (var i = 0; i < m.vals.length; i++) if (m.vals[i][0] === key) {
      m.sh.getRange(i + 2, 1, 1, row.length).setValues([row]); m.vals[i] = row; return;
    }
    m.sh.appendRow(row); m.vals.push(row);
  },
  deleteAttempt: function (sid, no) {
    var m = rows_('attempts', ATT_H_), key = sid + '|' + no;
    for (var i = m.vals.length - 1; i >= 0; i--) if (m.vals[i][0] === key) { m.sh.deleteRow(i + 2); m.vals.splice(i, 1); }
  },
  listAttempts: function (sid) {
    return rows_('attempts', ATT_H_).vals.filter(function (r) { return r[1] === sid; }).map(function (r) { return JSON.parse(r[6]); });
  },
  listAttemptsByStudent: function (no) {
    return rows_('attempts', ATT_H_).vals.filter(function (r) { return String(r[2]) === no; }).map(function (r) { return JSON.parse(r[6]); });
  }
};

var READ_ONLY_ = { ping: 1, listOpen: 1, myHistory: 1, bankStats: 1, listSessions: 1, sessionDetail: 1, gradebook: 1, getRoster: 1, bankList: 1, generate: 1, regenOne: 1, adminLogin: 1 };

function handleRequest_(req) {
  var lock = null;
  if (!READ_ONLY_[req.action]) {
    lock = LockService.getScriptLock();
    if (!lock.tryLock(20000)) return { ok: false, code: 'busy', message: '접속이 몰려 잠시 저장하지 못했습니다. 다시 눌러 주세요.' };
  }
  try {
    GAS_MEMO_ = {};
    var core = new Core(GasStore, BANK, OUTLINE);
    return core.handle(req);
  } finally { if (lock) lock.releaseLock(); }
}
function doPost(e) {
  var req = {};
  try { req = JSON.parse(e.postData.contents); } catch (x) { }
  return ContentService.createTextOutput(JSON.stringify(handleRequest_(req))).setMimeType(ContentService.MimeType.JSON);
}
function doGet(e) {
  var req = { action: (e && e.parameter && e.parameter.action) || 'ping' };
  if (req.action !== 'ping' && req.action !== 'listOpen') req = { action: 'ping' };
  return ContentService.createTextOutput(JSON.stringify(handleRequest_(req))).setMimeType(ContentService.MimeType.JSON);
}
// 편집기에서 한 번 실행: 기록 시트를 만들고 권한을 승인받는다.
function setup() {
  sheet_('sessions', SESS_H_); sheet_('attempts', ATT_H_); sheet_('log', ['시각', '회기', '학번', '종류', '내용']);
  Logger.log('기록 시트: ' + sheetBook_().getUrl());
}
