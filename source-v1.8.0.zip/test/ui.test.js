// 화면 시험: node test/ui.test.js  (dist/test 를 로컬 서버로 띄워 휴대폰·태블릿·노트북 크기로 확인)
const { chromium } = require('playwright');
const http = require('http'), fs = require('fs'), path = require('path');
const ROOT = path.join(__dirname, '../dist/test'), OUT = '/tmp/claude-0/-home-claude/3f0c5b8c-3216-5a2c-b4d7-bfee62afdd29/scratchpad/shots';
fs.mkdirSync(OUT, { recursive: true });
const srv = http.createServer((q, r) => {
  let p = decodeURIComponent(q.url.split('?')[0]); if (p === '/') p = '/index.html';
  const f = path.join(ROOT, p);
  if (!fs.existsSync(f)) { r.writeHead(404); r.end(); return; }
  const ext = path.extname(f); r.writeHead(200, { 'Content-Type': { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css' }[ext] || 'application/octet-stream' });
  r.end(fs.readFileSync(f));
}).listen(8765);
const BASE = 'http://localhost:8765/';
let pass = 0; function ok(c, m) { if (!c) throw new Error('실패: ' + m); pass++; console.log('  통과', m); }
async function hide(page) { await page.evaluate(() => { Object.defineProperty(document, 'visibilityState', { value: 'hidden', configurable: true }); document.dispatchEvent(new Event('visibilitychange')); }); }
async function show(page) { await page.evaluate(() => { Object.defineProperty(document, 'visibilityState', { value: 'visible', configurable: true }); document.dispatchEvent(new Event('visibilitychange')); }); }

(async () => {
  const browser = await chromium.launch();
  const CHART = fs.readFileSync('/tmp/claude-0/-home-claude/3f0c5b8c-3216-5a2c-b4d7-bfee62afdd29/scratchpad/npmchart/node_modules/chart.js/dist/chart.umd.js');
  const _nc = browser.newContext.bind(browser);
  browser.newContext = async (o) => { const c = await _nc(o); await c.route(/cdnjs|fonts\.googleapis|jsdelivr/, r => /chart/i.test(r.request().url()) ? r.fulfill({ body: CHART, contentType: 'text/javascript' }) : r.fulfill({ body: '', contentType: 'text/css' })); return c; };
  const errors = [];
  // ---------- 교수: 출제 ----------
  const ctx = await browser.newContext({ viewport: { width: 1366, height: 860 } });
  const P = await ctx.newPage(); P.on('pageerror', e => errors.push('교수 ' + e.message));
  await P.goto(BASE + 'admin.html');
  await P.fill('input[type=password]', 'demo1234'); await P.click('button[type=submit]');
  await P.waitForSelector('.range-label');
  // 시작: 제1장 첫 페이지 / 끝: 제2장 > 4) 대뇌 > (4) 실어증
  const selects = await P.$$('.range-side select');
  await selects[2].selectOption('c2'); await P.waitForTimeout(100);
  await selects[3].selectOption('c2-4-4-4');
  const label = await P.textContent('.range-label');
  console.log('  범위 표시:', label);
  ok(label.includes('제1장') && label.includes('첫 페이지 시작') && label.includes('실어증까지'), '범위 표시 문구');
  await P.screenshot({ path: OUT + '/admin-1-range.png', fullPage: true });
  await P.click('#tab-body .btn.accent');
  await P.waitForSelector('.pq');
  ok((await P.$$('.pq')).length === 9, '9문항 미리보기(객관식4·단답2·서술1·기출 변형1·기출 원문1)');
  ok(await P.isVisible('text=임용 기출 변형'), '기출 변형 표시');
  await P.click('.pq >> nth=0 >> text=다른 문항으로'); await P.waitForTimeout(400);
  await P.click('.pq >> nth=1 >> text=고치기'); await P.fill('.pq >> nth=1 >> textarea >> nth=0', '고친 발문 시험입니다. 옳은 것은?');
  await P.click('text=고친 내용 적용');
  ok(await P.isVisible('text=고친 발문 시험입니다'), '문항 고치기');
  await P.screenshot({ path: OUT + '/admin-2-preview.png', fullPage: true });
  await P.click('text=이대로 시험 열기'); await P.waitForTimeout(800); console.log('  토스트:', await P.evaluate(() => (document.querySelector('.toast')||{}).textContent));
  await P.waitForSelector('text=시험 회기');
  await P.waitForTimeout(500);
  ok(await P.isVisible('text=응시 중'), '회기 열림');

  // ---------- 학생 3명: 휴대폰·태블릿·노트북 ----------
  const devices = [
    { name: 'phone', vp: { width: 390, height: 844 }, ua: 'Mozilla/5.0 (iPhone; CPU iPhone OS 17_0 like Mac OS X) AppleWebKit/605.1.15 Mobile/15E148', no: '2024A101', nm: '휴대폰학생', mode: 'normal' },
    { name: 'tablet', vp: { width: 820, height: 1180 }, ua: 'Mozilla/5.0 (Linux; Android 13; SM-T870) AppleWebKit/537.36 Chrome/120 Safari/537.36', no: '2024A102', nm: '태블릿학생', mode: 'twice' },
    { name: 'laptop', vp: { width: 1366, height: 768 }, ua: undefined, no: '2024A103', nm: '노트북학생', mode: 'reload' }
  ];
  for (const d of devices) {
    console.log('[' + d.name + ']');
    const c = await browser.newContext({ viewport: d.vp, userAgent: d.ua, hasTouch: d.name !== 'laptop' });
    const dbNow = await P.evaluate(() => localStorage.getItem('quizdemo_v1'));
    await c.addInitScript(v => { if (!sessionStorage.getItem('seeded')) { localStorage.setItem('quizdemo_v1', v); sessionStorage.setItem('seeded', '1'); } }, dbNow);
    const p = await c.newPage(); p.on('pageerror', e => errors.push(d.name + ' ' + e.message));
    await p.goto(BASE);
    if (d.name === 'phone') {
      // 학번에 영문이 없으면 경고창 → 다시 입력
      await p.fill('#in-no', '252004'); await p.fill('#in-name', d.nm); await p.click('text=입장하기');
      await p.waitForSelector('text=학번에 영문이 빠졌어요');
      await p.screenshot({ path: OUT + '/s-phone-0-no-letter.png', fullPage: true });
      await p.click('.modal button:text-is("다시 입력")');
      ok((await p.isVisible('#in-no')) && !(await p.isVisible('text=이 시험 보기')), '영문 없는 학번: 경고 후 입력 화면 그대로');
    }
    await p.fill('#in-no', d.no.toLowerCase()); await p.fill('#in-name', d.nm);
    ok((await p.inputValue('#in-no')) === d.no, '학번 대문자');
    if (d.name === 'phone') await p.screenshot({ path: OUT + '/s-' + d.name + '-1-login.png', fullPage: true });
    await p.click('text=입장하기');
    await p.waitForSelector('text=이 시험 보기');
    await p.screenshot({ path: OUT + '/s-' + d.name + '-2-home.png', fullPage: true });
    await p.click('text=이 시험 보기');
    await p.check('#agree');
    if (d.name === 'phone') await p.screenshot({ path: OUT + '/s-' + d.name + '-3-rules.png', fullPage: true });
    await p.click('text=시험 시작');
    await p.waitForSelector('.qcard');
    const sw = await p.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1);
    ok(sw, '가로 넘침 없음');
    // 1번 답하기
    const opt = await p.$('.opt'); if (opt) await opt.click(); else await p.fill('.qcard input, .qcard textarea', '답');
    await p.screenshot({ path: OUT + '/s-' + d.name + '-4-exam.png', fullPage: true });
    // 붙여넣기 막힘
    if (d.mode === 'normal') {
      // 문항 끝까지 답하고 제출
      const n = (await p.$$('#qnav button')).length;
      for (let i = 0; i < n; i++) {
        await p.click('#qnav button >> nth=' + i);
        const o = await p.$('.opt'); if (o) { await o.click(); continue; }
        const inp = await p.$('.qcard input[type=text], .qcard textarea'); await inp.fill('브로카 실어증 측두엽 전두엽');
      }
      await p.waitForTimeout(3000);
      // 이탈 1회 → 경고
      await hide(p); await p.waitForTimeout(200); await show(p);
      await p.waitForSelector('.modal.alarm');
      ok((await p.textContent('.modal h2')).includes('1/2'), '1회 경고창');
      await p.screenshot({ path: OUT + '/s-' + d.name + '-5-warn.png', fullPage: false });
      await p.click('text=확인하고 계속 풀기');
      await p.click('#qnav button >> nth=' + (n - 1));
      await p.click('text=제출 전 확인'); await p.click('.modal .btn.accent');
      await p.waitForSelector('text=답안이 제출되었습니다');
      ok(!(await p.isVisible('.big-num')), '공개 전 점수 숨김');
      await p.screenshot({ path: OUT + '/s-' + d.name + '-6-submitted.png', fullPage: true });
    }
    if (d.mode === 'twice') {
      await hide(p); await show(p); await p.waitForSelector('.modal.alarm'); await p.click('text=확인하고 계속 풀기');
      // 태블릿: 가상 자판 등으로 초점만 잃음(blur 2.4초) → 경고·종료 없이 기록만
      await p.evaluate(() => { document.hasFocus = () => false; window.dispatchEvent(new Event('blur')); });
      await p.waitForTimeout(2400);
      await p.evaluate(() => { document.hasFocus = () => true; window.dispatchEvent(new Event('focus')); });
      await p.waitForTimeout(1200);
      ok(!(await p.isVisible('.modal.alarm')) && (await p.isVisible('.qcard')), '태블릿 초점 잃음: 경고 없이 계속 풀기');
      const notes = await p.evaluate(() => { const d = JSON.parse(localStorage.getItem('quizdemo_v1')); const a = Object.values(d.attempts).find(x => x.no === '2024A102'); return { n: (a.notes || []).length, v: a.violations.length }; });
      ok(notes.n === 1 && notes.v === 1, '초점 이탈은 기록 1건, 이탈 수는 그대로 1 ' + JSON.stringify(notes));
      // 글자 칸 입력 중(가상 자판)에는 3초 넘게 초점을 잃어도 세지 않음
      await p.evaluate(() => { const t = document.createElement('textarea'); t.id = 'kb-test'; document.querySelector('.qcard').appendChild(t); t.focus(); document.hasFocus = () => false; window.dispatchEvent(new Event('blur')); });
      await p.waitForTimeout(3600);
      await p.evaluate(() => { document.hasFocus = () => true; window.dispatchEvent(new Event('focus')); document.getElementById('kb-test').remove(); });
      await p.waitForTimeout(1200);
      ok(!(await p.isVisible('.modal.alarm')) && (await p.isVisible('.qcard')), '태블릿 입력 중 3초 넘게 초점 잃음: 세지 않음');
      // 3초 넘게 초점을 잃으면(입력 중 아님) 이탈 1회 → 2회째 종료
      await p.evaluate(() => { document.activeElement && document.activeElement.blur && document.activeElement.blur(); document.hasFocus = () => false; window.dispatchEvent(new Event('blur')); });
      await p.waitForTimeout(3600);
      await p.evaluate(() => { document.hasFocus = () => true; window.dispatchEvent(new Event('focus')); });
      await p.waitForSelector('.note.bad', { timeout: 8000 });
      ok((await p.textContent('#app')).includes('0점'), '2회째 즉시 종료·0점');
      await p.screenshot({ path: OUT + '/s-' + d.name + '-5-stop.png', fullPage: true });
    }
    if (d.mode === 'reload') {
      // 새로고침 = 화면 이탈 1회 (hidden 신호 + 재입장, 중복 없음)
      p.on('dialog', dl => dl.accept());
      await hide(p);
      await p.evaluate(() => { window.onbeforeunload = null; });
      await p.reload(); await p.waitForSelector('.qcard');
      await p.waitForSelector('.modal.alarm');
      ok((await p.textContent('.modal h2')).includes('1/2'), '새로고침 1회로만 기록');
      await p.click('text=확인하고 계속 풀기');
      ok((await p.$$('#vio i.on')).length === 1, '이탈 표시 1개');
    }
    const back = await p.evaluate(() => localStorage.getItem('quizdemo_v1'));
    await P.evaluate(v => localStorage.setItem('quizdemo_v1', v), back);
    await c.close();
  }
  // ---------- 교수: 현황·채점·그래프 ----------
  await P.click('text=새로고침'); await P.waitForTimeout(400);
  await P.click('text=열어 보기'); await P.waitForSelector('text=화면 이탈');
  const txt = await P.textContent('#detail');
  ok(txt.includes('이탈 종료(0점)') && txt.includes('휴대폰학생') && txt.includes('응시 중'), '교수 현황표');
  await P.screenshot({ path: OUT + '/admin-3-detail.png', fullPage: true });
  await P.click('#detail tr:has-text("휴대폰학생") >> text=답안'); await P.waitForSelector('text=이 채점으로 확정');
  await P.click('text=이 채점으로 확정'); await P.waitForTimeout(500);
  await P.screenshot({ path: OUT + '/admin-4-sheet.png', fullPage: true });
  await P.click('text=출제 문항 보기'); await P.waitForSelector('text=출제 문항 다시 보기');
  ok((await P.$$('#sheet .review-item')).length === 9, '출제 문항 다시 보기 9문항');
  await P.screenshot({ path: OUT + '/admin-4b-questions.png', fullPage: true });
  // 마감 뒤·공개 전: 학생은 문항과 내 답만 다시 본다(정답·점수 없음)
  await P.click('#detail >> text=응시 마감'); await P.click('.modal button:text-is("마감")'); await P.waitForSelector('#detail >> text=응시 열기'); await P.waitForTimeout(400);
  {
    const c3 = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
    const dbNow = await P.evaluate(() => localStorage.getItem('quizdemo_v1'));
    await c3.addInitScript(v => { if (!sessionStorage.getItem('seeded')) { localStorage.setItem('quizdemo_v1', v); sessionStorage.setItem('seeded', '1'); } }, dbNow);
    const p3 = await c3.newPage(); p3.on('pageerror', e => errors.push('공개 전 다시보기 ' + e.message));
    await p3.goto(BASE); await p3.fill('#in-no', '2024A101'); await p3.fill('#in-name', '휴대폰학생'); await p3.click('text=입장하기');
    await p3.waitForSelector('text=문항 다시 보기'); await p3.click('text=문항 다시 보기');
    await p3.waitForSelector('text=문항과 내 답');
    const tx = await p3.textContent('#app');
    ok((await p3.$$('.review-item')).length === 9 && tx.includes('내 답') && !tx.includes('정답:') && !(await p3.isVisible('.big-num')), '마감·공개 전: 문항 9개와 내 답만(정답·점수 없음)');
    await p3.screenshot({ path: OUT + '/s-phone-7b-review-before-release.png', fullPage: true });
    await c3.close();
  }
  await P.click('#detail >> text=결과 공개'); await P.waitForTimeout(600);
  // 학생이 공개된 결과를 다시 보기
  {
    const c2 = await browser.newContext({ viewport: { width: 390, height: 844 }, hasTouch: true });
    const dbNow = await P.evaluate(() => localStorage.getItem('quizdemo_v1'));
    await c2.addInitScript(v => { if (!sessionStorage.getItem('seeded')) { localStorage.setItem('quizdemo_v1', v); sessionStorage.setItem('seeded', '1'); } }, dbNow);
    const p2 = await c2.newPage(); p2.on('pageerror', e => errors.push('다시보기 ' + e.message));
    await p2.goto(BASE); await p2.fill('#in-no', '2024A101'); await p2.fill('#in-name', '휴대폰학생'); await p2.click('text=입장하기');
    await p2.waitForSelector('text=다시 보기'); await p2.waitForTimeout(600);
    await p2.screenshot({ path: OUT + '/s-phone-7-history.png', fullPage: true });
    await p2.click('text=다시 보기'); await p2.waitForSelector('text=문항별 확인');
    ok(await p2.isVisible('.big-num'), '공개 뒤 다시 보기 점수·문항');
    await p2.screenshot({ path: OUT + '/s-phone-8-review.png', fullPage: true });
    await c2.close();
  }
  await P.click('.tabs >> text=성적 그래프'); await P.waitForSelector('canvas'); await P.waitForTimeout(800);
  await P.selectOption('select[aria-label="학생 고르기"]', { index: 1 }); await P.waitForTimeout(600);
  await P.screenshot({ path: OUT + '/admin-5-graph.png', fullPage: true });
  ok((await P.$$('canvas')).length === 4, '그래프 4개');
  await P.click('.tabs >> text=명단·문항은행'); await P.waitForSelector('text=문항은행 판');
  ok(true, '문항은행 표');
  // 다시 풀기: 정답률 50% 미만 문항 → 같은 문항 + 같은 단원 새 문항 → 임시 저장
  await P.click('.tabs >> text=다시 풀기'); await P.waitForSelector('text=정답률 낮은 문항 고르기');
  await P.waitForSelector('#rt-list .card.flat');
  const nPick = await P.$$eval('#rt-list input[type=checkbox]:checked', l => l.length);
  ok(nPick > 1, '가장 최근 회기의 기준 미만 문항이 골라져 있음 ' + nPick);
  await P.screenshot({ path: OUT + '/admin-7-retest-pick.png', fullPage: true });
  ok(!(await P.$('input[name=rt-mode]')), '다시 풀기: 새 문항 고르기 없음');
  await P.click('text=다시 풀기 문항 만들기');
  await P.waitForSelector('#preview h2:has-text("문항 확인·고치기")');
  const chips = await P.$$eval('#preview .chip', l => l.map(x => x.textContent));
  ok(chips.filter(c => /^(원래 문항|같은 단원 새 문항)/.test(c)).length > 0 && chips.every(c => !c.startsWith('같은 단원 새 문항')), '다시 풀기: 원래 문항만');
  ok(!(await P.isVisible('#preview >> text=모두 다시 뽑기')), '다시 풀기 묶음에는 「모두 다시 뽑기」 없음');
  await P.screenshot({ path: OUT + '/admin-8-retest-preview.png', fullPage: true });
  await P.click('#preview >> text=이대로 시험 열기');
  await P.waitForFunction(() => Object.values(JSON.parse(localStorage.getItem('quizdemo_v1')).sessions).some(s => s.retest && s.status === 'open'));
  await P.waitForSelector('text=다시 풀기 —');
  ok(await P.isVisible('text=다시 풀기 —'), '다시 풀기 회기 열기 → 응시 현황 목록');
  // 학생 1명이 다시 풀기 응시(체험판 서버를 직접 불러서) → 성적 그래프에서 구분·효과·학생별 변화
  const rtRes = await P.evaluate(() => {
    const B = window.DEMO_BACKEND, lo = B.handle({ action: 'listOpen' }), rs = lo.sessions.find(s => s.retest); 
    const e = B.handle({ action: 'enter', sid: rs.id, studentNo: '2024A101', name: '휴대폰학생', eid: 'ui1' });
    const ans = {}; e.questions.forEach(q => { ans[q.qid] = q.type === 'mc' ? 0 : '브로카'; });
    return B.handle({ action: 'submit', sid: rs.id, studentNo: '2024A101', token: e.token, answers: ans }).ok;
  });
  ok(rtRes === true, '다시 풀기 회기 응시·제출 ' + rtRes);
  await P.click('.tabs >> text=성적 그래프'); await P.waitForSelector('text=다시 풀기 효과');
  const effTxt = await P.textContent('#tab-body');
  ok(effTxt.includes('같은 문항 정답률') && effTxt.includes('정규 평균') && effTxt.includes('[다시]'), '성적 그래프: 다시 풀기 효과 카드·정규/다시 풀기 구분');
  await P.selectOption('select[aria-label="학생 고르기"]', '2024A101');
  await P.waitForTimeout(300);
  const sumTxt = await P.textContent('#tab-body');
  ok(sumTxt.includes('다시 풀기 1회') && sumTxt.includes('다시 풀기 효과('), '학생별 점수 변화 요약(다시 풀기 점수·효과)');
  await P.screenshot({ path: OUT + '/admin-9-grade-retest.png', fullPage: true });
  // 학번 합치기: 영문자를 빠뜨린 학번(2024101)으로 다시 풀기를 본 학생 → 후보 → 교수가 마지막 클릭
  await P.evaluate(() => {
    const B = window.DEMO_BACKEND, rs = B.handle({ action: 'listOpen' }).sessions.find(s => s.retest);
    const e = B.handle({ action: 'enter', sid: rs.id, studentNo: '2024102', name: '태블릿학생', eid: 'ui2' });
    B.handle({ action: 'submit', sid: rs.id, studentNo: '2024102', token: e.token, answers: {} });
  });
  await P.click('.tabs >> text=성적 그래프'); await P.waitForSelector('text=같은 학생으로 보이는 학번');
  ok(true, '성적 그래프에 학번 합치기 알림');
  await P.click('text=학번 합치기로'); await P.waitForSelector('#merge-card .card.flat');
  const mtxt = await P.textContent('#merge-card');
  ok(mtxt.includes('태블릿학생') && mtxt.includes('같은 학생 가능성 높음') && mtxt.includes('2024A102') && mtxt.includes('← 추천'), '합치기 후보: 태블릿학생 2024A102 추천');
  await P.click('#merge-card button:text-is("합치기")');
  await P.waitForSelector('.modal >> text=학번 합치기');
  await P.screenshot({ path: OUT + '/admin-10-merge-confirm.png', fullPage: false });
  await P.click('.modal button:text-is("합치기")');
  await P.waitForSelector('#merge-card >> text=합치기 기록');
  const after = await P.evaluate(() => Object.keys(JSON.parse(localStorage.getItem('quizdemo_v1')).attempts).filter(k => /2024102$/.test(k)).length);
  ok(after === 0 && (await P.textContent('#merge-card')).includes('합칠 후보가 없습니다'), '합치기 완료: 2024102 기록 없음, 후보 없음');
  await P.screenshot({ path: OUT + '/admin-11-merge-done.png', fullPage: true });
  // 휴대폰 크기 교수 화면
  await P.setViewportSize({ width: 390, height: 844 }); await P.click('.tabs >> text=출제'); await P.waitForTimeout(300);
  ok(await P.evaluate(() => document.documentElement.scrollWidth <= window.innerWidth + 1), '교수 화면 휴대폰 가로 넘침 없음');
  await P.screenshot({ path: OUT + '/admin-6-phone.png', fullPage: true });
  console.log('오류', errors.length ? errors : '없음');
  console.log('통과', pass);
  await browser.close(); srv.close();
  if (errors.length) process.exit(1);
})().catch(e => { console.error(e); srv.close(); process.exit(1); });
