// 서버 핵심 로직 시험: node test/core.test.js
const fs = require('fs'), path = require('path'), assert = require('assert');
const { Core } = require('../server/core.js');
const bank = JSON.parse(fs.readFileSync(path.join(__dirname, '../dist/bank.json'), 'utf8'));
const outline = JSON.parse(fs.readFileSync(path.join(__dirname, '../dist/site/outline.js'), 'utf8').match(/window.OUTLINE=(.*?);\n/s)[1]);
let T = 1_700_000_000_000;
function mkStore() {
  const S = {}, A = {}, P = { ADMIN_PW: 'pw-test' }, C = {}, L = [];
  return {
    L, now: () => T, random: Math.random, sha256: s => 'h' + s,
    cacheGet: k => C[k] || null, cachePut: (k, v) => { C[k] = v; },
    getProp: k => P[k] || null, setProp: (k, v) => { P[k] = v; }, log: r => L.push(r),
    listSessions: () => Object.values(S).map(x => JSON.parse(JSON.stringify(x))), getSession: id => S[id] ? JSON.parse(JSON.stringify(S[id])) : null,
    putSession: s => { S[s.id] = JSON.parse(JSON.stringify(s)); }, deleteSession: id => { delete S[id]; },
    getAttempt: (sid, no) => A[sid + '|' + no] ? JSON.parse(JSON.stringify(A[sid + '|' + no])) : null, putAttempt: a => { A[a.sid + '|' + a.no] = JSON.parse(JSON.stringify(a)); },
    deleteAttempt: (sid, no) => { delete A[sid + '|' + no]; },
    listAttempts: sid => Object.values(A).filter(a => a.sid === sid).map(x => JSON.parse(JSON.stringify(x))),
    listAttemptsByStudent: no => Object.values(A).filter(a => a.no === no).map(x => JSON.parse(JSON.stringify(x)))
  };
}
const st = mkStore(), core = () => new Core(st, bank, outline), call = r => core().handle(r);
let n = 0; function ok(c, m) { assert.ok(c, m); n++; }

// 교수 로그인
ok(!call({ action: 'adminLogin', pw: 'x' }).ok, '틀린 비번 거부');
const adm = call({ action: 'adminLogin', pw: 'pw-test' }).adminToken; ok(adm, '로그인');
ok(call({ action: 'generate', range: {}, counts: { mc: 5 } }).code === 'admin_expired', '토큰 없이 교수 기능 거부');

// 범위: 제1장 처음 ~ 제2장 4. 신경기관 4) 대뇌 (4) 실어증
const R = { start: null, end: 'c2-4-4-4' };
const units = core().rangeUnits(R);
ok(units['c1'] && units['c2-4-4-4'] && !units['c2-5'] && !units['c3'], '범위 단원');
for (let k = 0; k < 20; k++) {
  const g = call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 4, short: 2, essay: 1, imyong: 1 } });
  ok(g.ok && g.questions.length === 8, '8문항 생성 ' + JSON.stringify(g.shortage));
  g.questions.forEach(q => ok(q.kind === 'imyong' || units[q.unit], '범위 밖 문항 ' + q.bankId));
}
ok(!call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 11 } }).ok, '11문항 거부');
ok(!call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 4 } }).ok, '4문항 거부');
// 범위 끝 노드 하위 포함: 제2장 끝까지
const u2 = core().rangeUnits({ start: 'c2', end: 'c2' }); ok(u2['c2-4-4-4'] && !u2['c1'] && !u2['c3'], '장 하나');

const g = call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 5, short: 2, essay: 1, imyong: 0 } });
const cs = call({ action: 'createSession', adminToken: adm, title: '시험1', range: R, rangeLabel: 'L', questions: g.questions, timeLimit: 10, showResult: 'immediate', shuffle: true, status: 'open' });
ok(cs.ok, '회기 생성'); const sid = cs.session.id;
const open = call({ action: 'listOpen' }); ok(open.sessions.length === 1 && !JSON.stringify(open).includes('"answer"'), '열린 목록, 정답 없음');

// 학생 A: 정상 제출
let e = call({ action: 'enter', sid, studentNo: '2024a001', name: '김가나', device: 'test' });
ok(e.ok && e.status === 'in_progress' && e.questions.length === 8, '입장');
const leak = JSON.stringify(e); ok(!leak.includes('"answer"') && !leak.includes('accept') && !leak.includes('keyPoints') && !leak.includes('explain'), '학생에게 정답 없음');
const S = st.getSession(sid);
// 정답 만들기 (화면 번호로 변환)
const att = st.getAttempt(sid, '2024A001');
const ans = {};
e.questions.forEach(v => {
  const q = S.questions.find(x => x.qid === v.qid);
  if (q.type === 'mc') { const perm = att.optOrder[q.qid] || q.options.map((_, i) => i); ans[q.qid] = perm.indexOf(q.answer); }
  else if (q.type === 'short') ans[q.qid] = ' ' + q.accept[0] + ' ';
  else ans[q.qid] = q.keyPoints.map(k => k.keywords[0]).join(' 그리고 ');
});
ok(call({ action: 'save', sid, studentNo: '2024A001', token: e.token, answers: ans }).ok, '저장');
ok(!call({ action: 'save', sid, studentNo: '2024A001', token: 'bad', answers: ans }).ok, '틀린 토큰 거부');
// 이탈 1회 (away → return 같은 번호) = 1회
let v = call({ action: 'violation', sid, studentNo: '2024A001', token: e.token, eventId: 'e1', kind: 'hidden', phase: 'away' });
v = call({ action: 'violation', sid, studentNo: '2024A001', token: e.token, eventId: 'e1', kind: 'hidden', phase: 'return' });
ok(v.violations === 1 && v.status === 'in_progress', '이탈 1회 경고');
T += 60000;
let sub = call({ action: 'submit', sid, studentNo: '2024A001', token: e.token, answers: {} });
ok(sub.ok && sub.status === 'submitted' && sub.result.score === 100, '만점 ' + sub.result.score);
ok(sub.result.items.length === 8 && sub.result.items.every(i => i.frac === 1), '문항별 결과');
// 제출 뒤 재입장 = 결과만, 이탈 증가 없음
e = call({ action: 'enter', sid, studentNo: '2024A001', name: '김가나' }); ok(e.status === 'submitted' && e.violations === 1, '제출 뒤 재입장');
ok(!call({ action: 'enter', sid, studentNo: '2024A001', name: '박다라' }).ok, '다른 이름 거부');

// 학생 B: 이탈 2회 → 즉시 종료 0점
e = call({ action: 'enter', sid, studentNo: '2024A002', name: '이마바' });
call({ action: 'violation', sid, studentNo: '2024A002', token: e.token, eventId: 'b1', kind: 'blur', phase: 'return' });
v = call({ action: 'violation', sid, studentNo: '2024A002', token: e.token, eventId: 'b2', kind: 'hidden', phase: 'away' });
ok(v.status === 'terminated' && v.violations === 2 && v.result.score === 0, '2회 종료 0점');
ok(!call({ action: 'violation', sid, studentNo: '2024A002', token: e.token, eventId: 'b3', kind: 'hidden' }).added, '종료 뒤 추가 없음');
// 교수 이탈 1회 취소 → 다시 응시 중
let f = call({ action: 'forgive', adminToken: adm, sid, studentNo: '2024A002' });
ok(f.attempt.status === 'in_progress' && f.attempt.violations.length === 1, '이탈 취소 복구');

// 학생 C: 앱을 닫음(away만 전송) → 재입장: 같은 이탈로 1회
e = call({ action: 'enter', sid, studentNo: '2024A003', name: '최사아' });
call({ action: 'violation', sid, studentNo: '2024A003', token: e.token, eventId: 'c1', kind: 'hidden', phase: 'away' });
e = call({ action: 'enter', sid, studentNo: '2024A003', name: '최사아' });
ok(e.status === 'in_progress' && e.violations === 1 && e.reentered, '닫고 재입장 1회');
// 아무 신호 없이 재입장(전송 실패) → reenter로 2회 → 종료
e = call({ action: 'enter', sid, studentNo: '2024A003', name: '최사아' });
ok(e.status === 'terminated' && e.violations === 2 && e.result.score === 0, '재입장 2회째 종료');

// 학생 D: 시간 초과 뒤 제출
e = call({ action: 'enter', sid, studentNo: '2024A004', name: '정자차' });
T += 13 * 60000;
sub = call({ action: 'submit', sid, studentNo: '2024A004', token: e.token, answers: {} });
ok(sub.status === 'submitted' && sub.result.score === 0, '시간 초과 제출(무응답 0점)');
// 단답형 채점 관용
const sq = { qid: 'x', type: 'short', accept: ['브로카 실어증'] };
ok(core().gradeOne(sq, '브로카실어증').frac === 1 && core().gradeOne(sq, '브로카 실어증입니다.').frac === 1 && core().gradeOne(sq, '베르니케').frac === 0, '단답 정규화');

// 교수 수동 채점
const det = call({ action: 'sessionDetail', adminToken: adm, id: sid }); ok(det.attempts.length === 4, '상세');
const ess = S.questions.find(q => q.type === 'essay');
let m = call({ action: 'setManual', adminToken: adm, sid, studentNo: '2024A001', qid: ess.qid, value: 0.5 });
ok(m.attempt.score === 93.8 && m.attempt.pending === 0, '서술형 수동 ' + m.attempt.score);
// 기록·성적
const hist = call({ action: 'myHistory', studentNo: '2024a001', name: '김가나' });
ok(hist.history.length === 1 && hist.history[0].score === 93.8, '내 점수');
const gb = call({ action: 'gradebook', adminToken: adm }); ok(gb.sessions[0].items.length === 8 && gb.students.length >= 3, '성적표');
// 결과 비공개 회기
const cs2 = call({ action: 'createSession', adminToken: adm, title: '시험2', questions: g.questions, showResult: 'after', status: 'open' });
e = call({ action: 'enter', sid: cs2.session.id, studentNo: '2024A001', name: '김가나' });
sub = call({ action: 'submit', sid: cs2.session.id, studentNo: '2024A001', token: e.token, answers: {} });
ok(!sub.result.released && sub.result.score === undefined && !sub.result.items, '비공개면 점수 숨김');
ok(call({ action: 'myHistory', studentNo: '2024A001', name: '김가나' }).history[1].score === undefined, '기록도 숨김');
// 명단
call({ action: 'setRoster', adminToken: adm, roster: [{ no: '2024a009', name: '한 하늘' }] });
ok(call({ action: 'enter', sid, studentNo: '2024A010', name: 'x' }).code === 'not_in_roster', '명단 밖 거부');
ok(call({ action: 'enter', sid, studentNo: '2024A009', name: '한하늘' }).ok, '명단 안 입장');
// 이전 회기 문항 빼기
const used = core().usedIds(); const g3 = call({ action: 'generate', adminToken: adm, range: R, counts: { mc: 5 }, excludeUsed: true });
ok(g3.questions.every(q => !used[q.bankId]), '이전 문항 제외');
// 전 범위 여러 조합
['c1', 'c3', 'c4', 'c5', 'c6'].forEach(c => { const r = call({ action: 'generate', adminToken: adm, range: { start: c, end: c }, counts: { mc: 4, short: 3, essay: 2, imyong: 1 } }); ok(r.ok, c); });
console.log('통과', n, '항목');
// v1.2: 결과 다시 보기, 기본 비공개, 기출 원문
{
  const csA = call({ action: 'createSession', adminToken: adm, title: '기본공개', questions: g.questions, status: 'open' });
  ok(csA.session.showResult === 'after' && csA.session.released === false, '기본은 교수 확인 뒤 공개');
  const eA = call({ action: 'enter', sid: csA.session.id, studentNo: '2024A009', name: '한하늘' });
  call({ action: 'submit', sid: csA.session.id, studentNo: '2024A009', token: eA.token, answers: {} });
  let mr = call({ action: 'myResult', sid: csA.session.id, studentNo: '2024A009', name: '한하늘' });
  ok(mr.ok && !mr.result.items && mr.result.score === undefined, '공개 전 다시 보기에 점수 없음');
  call({ action: 'updateSession', adminToken: adm, id: csA.session.id, patch: { released: true } });
  mr = call({ action: 'myResult', sid: csA.session.id, studentNo: '2024A009', name: '한하늘' });
  ok(mr.ok && mr.result.items.length === 8 && typeof mr.result.score === 'number', '공개 뒤 다시 보기');
  ok(!call({ action: 'myResult', sid: csA.session.id, studentNo: '2024A009', name: '남' }).ok, '다른 이름 거부');
  const nOrig = (bank.orig || []).length;
  if (nOrig) {
    let found = 0;
    ['c1', 'c2', 'c3', 'c4', 'c5', 'c6'].forEach(c => {
      const r = call({ action: 'generate', adminToken: adm, range: { start: c, end: c }, counts: { mc: 4, short: 2, essay: 1, imyong: 1, orig: 1 } });
      ok(r.ok, '원문 포함 생성 ' + c + ' ' + r.message);
      const o = r.questions.filter(q => q.kind === 'orig'); ok(o.length <= 1, '원문 1개 이하');
      if (o.length) { found++; ok(o[0].type === 'essay' && o[0].keyPoints.length && o[0].code, '원문 형식'); }
    });
    ok(found >= 1, '원문이 한 범위 이상에서 나옴 ' + found);
  }
}
console.log('추가 시험 통과', n);
// v1.2.1: 제출 마무리·일괄 채점
{
  const cs = call({ action: 'createSession', adminToken: adm, title: '마무리시험', questions: g.questions, status: 'open', showResult: 'after' });
  const sid2 = cs.session.id;
  const e1 = call({ action: 'enter', sid: sid2, studentNo: '2024A009', name: '한하늘' });
  const S2 = st.getSession(sid2), a1 = st.getAttempt(sid2, '2024A009');
  const ans = {}; e1.questions.forEach(v => { const q = S2.questions.find(x => x.qid === v.qid); if (q.type === 'mc') { const perm = a1.optOrder[q.qid] || q.options.map((_, i) => i); ans[q.qid] = perm.indexOf(q.answer); } else if (q.type === 'short') ans[q.qid] = q.accept[0]; });
  const savedAt = T; call({ action: 'save', sid: sid2, studentNo: '2024A009', token: e1.token, answers: ans });
  T += 3 * 24 * 3600 * 1000;
  const f = call({ action: 'finalizeSession', adminToken: adm, id: sid2 });
  ok(f.ok && f.finalized.length === 1 && f.finalized[0].score > 0, '응시 중 → 저장된 답으로 제출 처리 ' + JSON.stringify(f.finalized));
  const a2 = st.getAttempt(sid2, '2024A009');
  ok(a2.status === 'submitted' && a2.endReason === 'admin_finalize' && a2.submittedAt === savedAt, '제출 시각은 마지막 저장 시각');
  const f2 = call({ action: 'finalizeSession', adminToken: adm, id: sid2 }); ok(f2.finalized.length === 0, '두 번 눌러도 안전');
  ok(!call({ action: 'finalizeSession', id: sid2 }).ok, '교수 로그인 없이 거부');
  // 늦게 도착한 학생 제출 → 이미 제출 처리된 기록을 그대로 돌려줌
  const late = call({ action: 'submit', sid: sid2, studentNo: '2024A009', token: e1.token, answers: {} });
  ok(late.ok && late.status === 'submitted', '늦은 제출 요청도 정상 응답');
}

// ---------- 다시 풀기: 정답률 50% 미만 문항 ----------
{
  call({ action: 'setRoster', adminToken: adm, roster: [] });
  const R5 = { start: 'c5', end: 'c5-3-2' };
  const mkSess = (title, counts) => {
    const g = call({ action: 'generate', adminToken: adm, range: R5, counts, excludeUsed: false });
    ok(g.ok, '다시 풀기용 회기 출제 ' + (g.message || ''));
    const c = call({ action: 'createSession', adminToken: adm, title, range: R5, rangeLabel: '5장', questions: g.questions, status: 'open' });
    return c.session.id;
  };
  // 학생 n명이 응시: wrongFor(q, i)가 참이면 그 문항을 틀리게 답한다
  const sitAll = (sid, nStu, wrongFor) => {
    const S = st.getSession(sid);
    for (let i = 0; i < nStu; i++) {
      const no = ('RT' + sid.slice(-4) + i).toUpperCase();
      const e = call({ action: 'enter', sid, studentNo: no, name: '재' + i }); if (!e.ok) throw new Error('입장 실패 ' + JSON.stringify(e));
      const a = st.getAttempt(sid, no), ans = {};
      S.questions.forEach(q => {
        const wrong = wrongFor(q, i);
        if (q.type === 'mc') { const perm = a.optOrder[q.qid] || q.options.map((_, k) => k); ans[q.qid] = perm.indexOf(wrong ? (q.answer + 1) % q.options.length : q.answer); }
        else if (q.type === 'short') ans[q.qid] = wrong ? '모름' : q.accept[0];
        else ans[q.qid] = wrong ? '' : (q.keyPoints || []).map(k => (k.keywords || [])[0] || '').join(' ');
      });
      call({ action: 'submit', sid, studentNo: no, token: e.token, answers: ans });
    }
    return S;
  };
  const sA = mkSess('다시풀기 원본 A', { mc: 5, short: 3, essay: 0 });
  const SA = sitAll(sA, 4, (q, i) => (q.qid === 'q1' || q.qid === 'q2') ? i < 3 : (q.qid === 'q3' ? i < 2 : false));   // q1·q2 25%, q3 50%(기준 미만 아님)
  const sB = mkSess('다시풀기 원본 B', { mc: 4, short: 2, essay: 0 });
  sitAll(sB, 5, (q, i) => q.qid === 'q4' ? i < 4 : false);   // q4 20%
  const w = call({ action: 'weakItems', adminToken: adm, threshold: 50 });
  ok(w.ok, '기준 미만 문항 조회');
  const wa = w.sessions.find(s => s.id === sA), wb = w.sessions.find(s => s.id === sB);
  ok(wa.takers === 4 && wa.weak.map(x => x.qid).sort().join() === 'q1,q2' && wa.weak[0].rate === 25, '회기 A: q1·q2(25%), 50%인 q3는 빠짐 ' + JSON.stringify(wa.weak.map(x => [x.qid, x.rate])));
  ok(wb.weak.length === 1 && wb.weak[0].qid === 'q4' && wb.weak[0].rate === 20, '회기 B: q4(20%)');
  ok(call({ action: 'weakItems', adminToken: adm, threshold: 60 }).sessions.find(s => s.id === sA).weak.length === 3, '기준 60%면 q3(50%)도 포함');
  ok(!call({ action: 'weakItems', threshold: 50 }).ok, '교수 로그인 없이 거부');
  const picks = [{ sid: sA, qid: 'q1' }, { sid: sA, qid: 'q2' }, { sid: sB, qid: 'q4' }];
  // 같은 문항 그대로, 모아서
  const b1 = call({ action: 'retestBuild', adminToken: adm, picks, mode: 'same', split: false, threshold: 50 });
  ok(b1.ok && b1.groups.length === 1 && b1.groups[0].questions.length === 3, '모아서 한 묶음 3문항');
  const g1 = b1.groups[0];
  ok(g1.questions.every(q => q.retestOf && q.retestOf.how === 'same' && q.answer !== undefined || q.accept), '원래 문항(정답 포함) 그대로');
  ok(g1.questions.some(q => q.retestOf.sid === sB && q.retestOf.rate === 20), '원래 회기·정답률 표시');
  ok(g1.sources.length === 2 && /정답률 50% 미만/.test(g1.rangeLabel), '출처 2회기, 범위 표시');
  // 회기별 따로
  const b2 = call({ action: 'retestBuild', adminToken: adm, picks, mode: 'same', split: true });
  ok(b2.groups.length === 2 && b2.groups[0].questions.length === 2 && b2.groups[1].questions.length === 1, '회기별로 따로 2묶음(2문항·1문항)');
  // 같은 단원 새 문항
  const used = core().usedIds();
  const b3 = call({ action: 'retestBuild', adminToken: adm, picks, mode: 'similar', perItem: 2, split: false });
  ok(b3.ok, '새 문항 묶음 ' + (b3.message || ''));
  const g3 = b3.groups[0], ids3 = g3.questions.map(q => q.bankId);
  ok(new Set(ids3).size === ids3.length, '새 문항 중복 없음');
  g3.questions.forEach(q => {
    if (q.retestOf.how === 'same') return;
    const src = st.getSession(q.retestOf.sid).questions.find(x => x.qid === q.retestOf.qid);
    ok(q.bankId !== src.bankId, '원래 문항과 다른 문항');
    if (q.retestOf.how === 'same_type' || q.retestOf.how === 'same_unit') ok(core().rangeUnits({ start: src.unit, end: src.unit })[q.unit], '같은 단원 ' + q.unit + ' ← ' + src.unit);
    if (q.retestOf.how === 'same_type') ok(q.type === src.type && !used[q.bankId], '같은 유형·이전에 안 낸 문항');
  });
  ok(g3.questions.filter(q => q.retestOf.how !== 'same').length + g3.notes.length >= 3, '원래 문항마다 새 문항(없으면 안내)');
  // 둘 다 + 최대 문항 수
  const b4 = call({ action: 'retestBuild', adminToken: adm, picks, mode: 'both', perItem: 1, limit: 4 });
  ok(b4.groups[0].questions.length === 4 && b4.groups[0].notes.some(t => /최대 4문항/.test(t)), '둘 다: 6문항 중 정답률 낮은 4문항만 ' + b4.groups[0].questions.length);
  ok(!call({ action: 'retestBuild', adminToken: adm, picks: [] }).ok, '고른 문항 없으면 거부');
  // 다시 풀기 회기: 1~30문항 허용(보통 회기는 5~10 그대로)
  ok(!call({ action: 'createSession', adminToken: adm, title: 'x', questions: g1.questions }).ok, '보통 회기 3문항 거부');
  const cr = call({ action: 'createSession', adminToken: adm, title: g1.title, rangeLabel: g1.rangeLabel, questions: g1.questions, status: 'open', retest: { threshold: 50, mode: 'same', sources: g1.sources } });
  ok(cr.ok && cr.session.retest && cr.session.retest.sources.length === 2 && cr.session.questions.length === 3, '다시 풀기 회기 3문항 생성');
  ok(!call({ action: 'createSession', adminToken: adm, title: 'x', questions: [], retest: {} }).ok, '다시 풀기 0문항 거부');
  const e = call({ action: 'enter', sid: cr.session.id, studentNo: 'RTSTU1', name: '재응시' });
  ok(e.ok && e.questions.length === 3 && e.questions.every(q => q.retestOf === undefined && q.answer === undefined && q.accept === undefined), '학생 화면에는 원래 정답률·정답 안 보냄');
  ok(call({ action: 'listOpen' }).sessions.find(s => s.id === cr.session.id).retest === true, '목록에 다시 풀기 표시');
  // 다시 풀기 효과·점수 구분: 원래 회기 A에서 q1·q2를 틀린 학생이 다시 풀기에서 모두 맞힘
  {
    const rid = cr.session.id, RS = st.getSession(rid), no0 = ('RT' + sA.slice(-4) + '0').toUpperCase();
    const e0 = call({ action: 'enter', sid: rid, studentNo: no0, name: '재0' });
    const a0 = st.getAttempt(rid, no0), ans = {};
    RS.questions.forEach(q => {
      if (q.type === 'mc') { const perm = a0.optOrder[q.qid] || q.options.map((_, k) => k); ans[q.qid] = perm.indexOf(q.answer); }
      else if (q.type === 'short') ans[q.qid] = q.accept[0];
      else ans[q.qid] = (q.keyPoints || []).map(k => (k.keywords || [])[0] || '').join(' ');
    });
    call({ action: 'submit', sid: rid, studentNo: no0, token: e0.token, answers: ans });
    const gb = call({ action: 'gradebook', adminToken: adm });
    const gr = gb.sessions.find(s => s.id === rid), ga = gb.sessions.find(s => s.id === sA);
    ok(gr.retest && gr.retest.sources.length === 2 && !ga.retest, '성적표: 다시 풀기 회기 표시(정규 회기는 없음)');
    const s0 = gb.students.find(x => x.no === no0);
    ok(s0.scores[rid] === 100 && s0.cmp[rid] && s0.cmp[rid].n === 2 && s0.cmp[rid].before === 0 && s0.cmp[rid].after === 100, '학생 다시 풀기 효과: 원래 회기에서 본 2문항 0% → 100% ' + JSON.stringify(s0.cmp[rid]));
    ok(gr.compare && gr.compare.n === 1 && gr.compare.before === 0 && gr.compare.after === 100, '회기 다시 풀기 효과 요약');
    ok(!s0.cmp[sA], '정규 회기에는 비교 없음');
    // 학생 화면: 공개된 회기에서만 비교가 나간다
    let hh = call({ action: 'myHistory', studentNo: no0, name: '재0' }).history.find(x => x.sid === rid);
    ok(hh.retest && hh.compare === undefined && hh.score === undefined, '공개 전: 점수·비교 숨김');
    call({ action: 'updateSession', adminToken: adm, id: rid, patch: { released: true } });
    hh = call({ action: 'myHistory', studentNo: no0, name: '재0' }).history.find(x => x.sid === rid);
    ok(hh.score === 100 && hh.compare === null, '다시 풀기만 공개되고 원래 회기가 비공개면 비교 안 함');
    call({ action: 'updateSession', adminToken: adm, id: sA, patch: { released: true } });
    hh = call({ action: 'myHistory', studentNo: no0, name: '재0' }).history.find(x => x.sid === rid);
    ok(hh.compare && hh.compare.before === 0 && hh.compare.after === 100, '둘 다 공개: 학생 화면에 같은 문항 0% → 100%');
  }
  // 다시 풀기 회기도 다음 다시 풀기의 원본이 될 수 있음
  ok(call({ action: 'weakItems', adminToken: adm, threshold: 50 }).sessions.find(s => s.id === cr.session.id).retest === true, '다시 풀기 회기도 목록에');
}

// ---------- 학생: 지난 시험 이력과 문항 다시 보기 ----------
{
  call({ action: 'setRoster', adminToken: adm, roster: [] });
  const g = call({ action: 'generate', adminToken: adm, range: { start: 'c5', end: 'c5-3-2' }, counts: { mc: 4, short: 2, essay: 1 }, excludeUsed: false });
  const c = call({ action: 'createSession', adminToken: adm, title: '이력 시험', questions: g.questions, status: 'open' });
  const sid = c.session.id;
  const e = call({ action: 'enter', sid, studentNo: 'HIS001', name: '이력' });
  const qMc = e.questions.find(q => q.type === 'mc'), qSh = e.questions.find(q => q.type === 'short');
  call({ action: 'submit', sid, studentNo: 'HIS001', token: e.token, answers: { [qMc.qid]: 0, [qSh.qid]: '내 답' } });
  const who = { studentNo: 'HIS001', name: '이력' };
  let h = call(Object.assign({ action: 'myHistory' }, who)).history.find(x => x.sid === sid);
  ok(h && !h.closed && !h.released && h.score === undefined && h.n === 7, '응시 중 회기: 이력에 보이되 점수 없음');
  let m = call(Object.assign({ action: 'myResult', sid }, who));
  ok(m.ok && !m.result.items, '응시 중 회기: 문항 안 보냄(다른 학생 보호)');
  call({ action: 'updateSession', adminToken: adm, id: sid, patch: { status: 'closed' } });
  h = call(Object.assign({ action: 'myHistory' }, who)).history.find(x => x.sid === sid);
  ok(h.closed && !h.released && h.score === undefined, '마감·공개 전: 점수는 숨김');
  m = call(Object.assign({ action: 'myResult', sid }, who));
  const it = m.result.items;
  ok(m.result.reviewOnly && it.length === 7 && m.result.score === undefined, '마감·공개 전: 문항 7개와 내 답');
  ok(it.every(x => x.correct === undefined && x.frac === undefined && x.explain === undefined && x.model === undefined && x.points === undefined), '마감·공개 전: 정답·채점·해설 없음');
  ok(it.some(x => x.mine === '내 답') && it.some(x => x.type === 'mc' && x.options && x.mine === 0), '내 답(객관식은 내가 본 보기 순서) 표시');
  call({ action: 'updateSession', adminToken: adm, id: sid, patch: { released: true } });
  m = call(Object.assign({ action: 'myResult', sid }, who));
  ok(!m.result.reviewOnly && m.result.items.every(x => x.frac !== undefined) && m.result.score !== undefined, '공개 뒤: 점수·정답·해설까지');
  ok(!call({ action: 'myResult', sid, studentNo: 'HIS001', name: '다른사람' }).ok, '이름이 다르면 거부');
}

// ---------- 학번 잘못 입력 합치기 ----------
{
  call({ action: 'setRoster', adminToken: adm, roster: [] });
  const mk = (title) => { const g = call({ action: 'generate', adminToken: adm, range: { start: 'c5', end: 'c5-3-2' }, counts: { mc: 5, short: 0, essay: 0 }, excludeUsed: false }); return call({ action: 'createSession', adminToken: adm, title, questions: g.questions, status: 'open' }).session.id; };
  const X = mk('합치기 X'), Y = mk('합치기 Y'), Z = mk('합치기 Z');
  const sit = (sid, no, name) => { const e = call({ action: 'enter', sid, studentNo: no, name }); if (!e.ok) throw new Error('입장 ' + no + ' ' + e.message); call({ action: 'submit', sid, studentNo: no, token: e.token, answers: {} }); return e; };
  sit(X, '252004', '김태희'); sit(Y, '25B2004', '김태희'); sit(Z, '25B2004', '김태희');   // 영문자 빠뜨림
  sit(X, '20252013', '이은우'); sit(Y, '25B2013', '이은우');                         // 연도 네 자리
  sit(X, '25B3001', '강민재'); sit(X, '25B2001', '강민재'); sit(Y, '25B3001', '강민재'); // 같은 회기에 둘 다 → 다른 사람
  sit(X, '25B2007', '박진연'); sit(Y, '25B2O07', '박진연');                          // 한 글자 다름(O)
  sit(X, '25B2099', '다른이'); sit(Y, '25B2098', '또다른');                           // 이름 다르면 후보 아님
  call({ action: 'setRoster', adminToken: adm, roster: [{ no: '25B2004', name: '김태희' }, { no: '25B2013', name: '이은우' }, { no: '25B2007', name: '박진연' }] });
  const d = call({ action: 'dupCandidates', adminToken: adm });
  call({ action: 'setRoster', adminToken: adm, roster: [] });
  ok(d.ok && typeof d.mainShape === 'string', '가장 많은 학번 형식 ' + d.mainShape);
  ok(core().idKey_ === undefined && require('../server/core.js').idKey_('20252013') === '25|2013' && require('../server/core.js').idKey_('252013') === '25|2013' && require('../server/core.js').idKey_('25B2013') === '25|2013', '학번 열쇠: 연도·끝 네 자리');
  const gK = d.groups.find(g => g.name === '김태희'), gL = d.groups.find(g => g.name === '이은우'), gP = d.groups.find(g => g.name === '박진연');
  ok(gK && gK.confidence === 'high' && gK.suggest === '25B2004' && gK.members.length === 2, '김태희: 252004·25B2004 높음, 25B2004 추천');
  ok(gL && gL.confidence === 'high' && gL.suggest === '25B2013', '이은우: 20252013·25B2013 높음');
  ok(gP && gP.confidence === 'medium' && gP.suggest === '25B2007', '박진연: 한 글자 다름 → 확인 필요, 명단 학번 추천');
  ok(!d.groups.find(g => g.name === '강민재') && d.doubtful.find(g => g.name === '강민재' && g.conflict.length === 1), '강민재: 같은 회기에 둘 다 → 합치기 막음');
  ok(!d.groups.concat(d.doubtful).some(g => g.name === '다른이' || g.name === '또다른'), '이름이 다르면 후보 아님');
  ok(!call({ action: 'dupCandidates' }).ok, '교수 로그인 없으면 거부');
  // 미리 보기(check) → 합치기
  const ck = call({ action: 'mergeStudents', adminToken: adm, to: '25B2004', from: ['252004'], check: true });
  ok(ck.ok && ck.moves.length === 1 && ck.moves[0].sid === X && ck.name === '김태희', '합치기 미리 보기: 1건');
  ok(st.getAttempt(X, '252004'), '미리 보기는 아무것도 바꾸지 않음');
  const mg = call({ action: 'mergeStudents', adminToken: adm, to: '25B2004', from: ['252004'] });
  ok(mg.ok && mg.merged.moved === 1 && !st.getAttempt(X, '252004') && st.getAttempt(X, '25B2004').mergedFrom[0] === '252004', '합치기: X 기록이 25B2004로');
  const gb = call({ action: 'gradebook', adminToken: adm }), kt = gb.students.filter(s => s.name === '김태희');
  ok(kt.length === 1 && Object.keys(kt[0].scores).filter(k => [X, Y, Z].includes(k)).length === 3, '성적표에서 한 학생(3회기)');
  // 앞으로 잘못 쓴 학번으로 들어와도 이어짐
  const W = mk('합치기 W');
  const ew = call({ action: 'enter', sid: W, studentNo: '252004', name: '김태희' });
  ok(ew.ok && st.getAttempt(W, '25B2004') && !st.getAttempt(W, '252004'), '잘못 쓴 학번으로 입장 → 합친 학번으로 기록');
  ok(call({ action: 'save', sid: W, studentNo: '252004', token: ew.token, answers: {} }).ok, '잘못 쓴 학번으로 저장도 이어짐');
  ok(call({ action: 'myHistory', studentNo: '252004', name: '김태희' }).history.length >= 3, '잘못 쓴 학번으로 내 기록 조회 → 합친 기록');
  const other = call({ action: 'enter', sid: W, studentNo: '252004', name: '딴사람' });
  ok(other.ok && st.getAttempt(W, '252004').name === '딴사람', '이름이 다르면 이어 주지 않음');
  // 같은 회기 충돌·이름 다름은 거부
  ok(call({ action: 'mergeStudents', adminToken: adm, to: '25B3001', from: ['25B2001'] }).code === 'merge_clash', '같은 회기에 둘 다 있으면 합치기 거부');
  ok(call({ action: 'mergeStudents', adminToken: adm, to: '25B2099', from: ['25B2098'] }).code === 'bad_merge', '이름이 다르면 합치기 거부');
  // 되돌리기
  const m2 = call({ action: 'mergeStudents', adminToken: adm, to: '25B2013', from: ['20252013'] });
  ok(m2.ok && st.getAttempt(X, '25B2013') && !st.getAttempt(X, '20252013'), '이은우 합치기');
  const un = call({ action: 'unmerge', adminToken: adm, id: m2.merged.id });
  ok(un.ok && un.restored === 1 && st.getAttempt(X, '20252013') && !st.getAttempt(X, '25B2013') && st.getAttempt(Y, '25B2013'), '되돌리기: 원래 학번으로');
  ok(!call({ action: 'unmerge', adminToken: adm, id: m2.merged.id }).ok, '두 번 되돌리기 거부');
  const d2 = call({ action: 'dupCandidates', adminToken: adm });
  ok(d2.groups.find(g => g.name === '이은우') && !d2.groups.find(g => g.name === '김태희') && d2.merges.length === 2 && d2.merges.some(m => m.undone), '되돌린 뒤 다시 후보·기록 2건');
  ok(core().resolveNo('20252013', '이은우') === '20252013', '되돌리면 이어 주기도 지움');
}
console.log('마무리 시험 통과', n);
