// Apps Script 모의 환경에서 실제 Code.gs를 돌려 동시 접속 경로(잠금 없는 저장, 제출 접수, 접수분 채점)를 검사한다.
// node test/gas.test.js
const fs = require('fs'), vm = require('vm'), path = require('path');
const CODE = fs.readFileSync(path.join(__dirname, '../dist/server/Code.gs'), 'utf8');
let pass = 0, fail = 0;
function ok(c, m) { if (c) pass++; else { fail++; console.log('실패:', m); } }

function makeEnv() {
  const ops = { read: 0, write: 0 };
  // 시트가 숫자처럼 생긴 글자를 숫자로 바꾸는 것까지 흉내 낸다
  const conv = v => (typeof v === 'string' && /^\d+$/.test(v) && v.length < 15) ? Number(v) : v;
  function Sheet(name) { this.name = name; this.data = []; }
  Sheet.prototype.getLastRow = function () { return this.data.length; };
  Sheet.prototype.cell = function (r, c) { const row = this.data[r - 1] || []; const v = row[c - 1]; return v === undefined ? '' : v; };
  Sheet.prototype.getRange = function (r, c, nr, nc) { return new Range(this, r, c, nr || 1, nc || 1); };
  Sheet.prototype.appendRow = function (row) { ops.write++; this.data.push(row.map(conv)); };
  Sheet.prototype.deleteRow = function (r) { ops.write++; this.data.splice(r - 1, 1); };
  Sheet.prototype.setFrozenRows = function () { };
  function Range(sh, r, c, nr, nc) { Object.assign(this, { sh, r, c, nr, nc }); }
  Range.prototype.getValues = function () { ops.read++; const out = []; for (let i = 0; i < this.nr; i++) { const row = []; for (let j = 0; j < this.nc; j++) row.push(this.sh.cell(this.r + i, this.c + j)); out.push(row); } return out; };
  Range.prototype.getValue = function () { ops.read++; return this.sh.cell(this.r, this.c); };
  Range.prototype.setValues = function (vals) { ops.write++; vals.forEach((row, i) => row.forEach((v, j) => { const R = this.r + i - 1; while (this.sh.data.length <= R) this.sh.data.push([]); this.sh.data[R][this.c + j - 1] = conv(v); })); };
  Range.prototype.setValue = function (v) { this.setValues([[v]]); };
  Range.prototype.getRow = function () { return this.r; };
  Range.prototype.createTextFinder = function (text) {
    const rg = this; let entire = false, mcase = false;
    const tf = {
      matchEntireCell(b) { entire = b; return tf; }, matchCase(b) { mcase = b; return tf; },
      findAll() {
        ops.read++; const out = [];
        for (let i = 0; i < rg.nr; i++) for (let j = 0; j < rg.nc; j++) {
          const v = String(rg.sh.cell(rg.r + i, rg.c + j)); const a = mcase ? v : v.toLowerCase(), t = mcase ? text : text.toLowerCase();
          if (entire ? a === t : a.indexOf(t) >= 0) out.push(new Range(rg.sh, rg.r + i, rg.c + j, 1, 1));
        }
        return out;
      }
    };
    return tf;
  };
  const book = { sheets: {}, getSheetByName(n) { return this.sheets[n] || null; }, insertSheet(n) { return (this.sheets[n] = new Sheet(n)); }, getSheets() { return Object.values(this.sheets); }, deleteSheet() { }, getId() { return 'BOOK'; }, getUrl() { return 'url'; } };
  const props = { ADMIN_PW: 'pw', SHEET_ID: 'BOOK' }, cache = {};
  const lockState = { busy: false, held: false };
  let clock = 1800000000000;
  const ctx = {
    console, JSON, Math, Object, String, Number, Array, Date: class extends Date { constructor(...a) { if (a.length) super(...a); else super(clock); } static now() { return clock; } },
    SpreadsheetApp: { openById: () => book, create: () => book, flush: () => { ops.flush = (ops.flush || 0) + 1; } },
    PropertiesService: { getScriptProperties: () => ({ getProperty: k => (k in props ? props[k] : null), setProperty: (k, v) => { props[k] = String(v); } }) },
    CacheService: { getScriptCache: () => ({ get: k => (k in cache ? cache[k] : null), put: (k, v) => { cache[k] = String(v); }, remove: k => { delete cache[k]; }, removeAll: ks => ks.forEach(k => { delete cache[k]; }) }) },
    LockService: { getScriptLock: () => ({ tryLock: () => { if (lockState.busy) return false; lockState.held = true; return true; }, waitLock: () => { lockState.held = true; }, releaseLock: () => { lockState.held = false; } }) },
    Utilities: { computeDigest: (a, s) => Array.from(require('crypto').createHash('sha256').update(s).digest()), DigestAlgorithm: {}, Charset: {} },
    ContentService: { createTextOutput: t => ({ setMimeType: () => t }), MimeType: {} },
    Logger: { log: m => { ctx.$log.push(String(m)); } }, $log: []
  };
  vm.createContext(ctx);
  vm.runInContext(CODE, ctx);
  ctx.Date.now = () => clock;
  const env = {
    ctx, book, props, cache, lockState, ops,
    tick(ms) { clock += ms; },
    call(req) { return JSON.parse(JSON.stringify(ctx.handleRequest_(JSON.parse(JSON.stringify(req))))); },
    att(sid, no) { const sh = book.sheets.attempts; const row = sh.data.find(r => r[0] === sid + '|' + no); return row ? { a: JSON.parse(row[6]), draft: row[8] ? JSON.parse(row[8]) : null, status: row[4] } : null; }
  };
  ctx.setup();
  return env;
}

// ---- 준비: 회기 만들기 ----
const E = makeEnv();
const adm = E.call({ action: 'adminLogin', pw: 'pw' }).adminToken; ok(adm, '교수 로그인');
const g = E.call({ action: 'generate', adminToken: adm, range: { start: 'c5', end: 'c5-3-2' }, counts: { mc: 6, short: 4, essay: 0, imyong: 0, orig: 0 } });
ok(g.ok && g.questions.length === 10, '10문항 출제 ' + (g.message || ''));
const cs = E.call({ action: 'createSession', adminToken: adm, title: '모의', questions: g.questions, timeLimit: 20, shuffle: true, status: 'open', showResult: 'after' });
ok(cs.ok, '회기 생성'); const sid = cs.session.id;
ok(E.book.sheets.attempts.data[0][8] === 'draft', '9열 머리글 draft');

// ---- 1. 입장(잠금) → 저장(잠금 없음) ----
const en = E.call({ action: 'enter', sid, studentNo: '2012111', name: '가나다' });
ok(en.ok && en.status === 'in_progress', '입장');
const qs = en.questions, tok = en.token;
const ans1 = {}; qs.forEach(q => { ans1[q.qid] = q.type === 'mc' ? 0 : '답' + q.qid; });
E.lockState.busy = true;     // 다른 요청이 잠금을 쥐고 있어도
E.tick(5000);
const sv = E.call({ action: 'save', sid, token: tok, studentNo: '2012111', answers: ans1 });
ok(sv.ok, '잠금이 막혀 있어도 자동 저장 성공');
let row = E.att(sid, '2012111');
ok(row.draft && Object.keys(row.draft.ans).length === 10 && Object.keys(row.a.answers).length === 0, '저장은 draft 칸에만, 기록 JSON은 그대로');
ok(typeof E.book.sheets.attempts.data[1][2] === 'number', '숫자 학번이 시트에서 숫자로 바뀐 상황');
E.lockState.busy = false;
// 교수 화면: 답 수가 draft까지 합쳐 보인다
const d1 = E.call({ action: 'sessionDetail', adminToken: adm, id: sid });
ok(d1.ok && d1.attempts[0].answered === 10, '교수 화면 답 수에 자동 저장분 반영');

// ---- 2. 이탈(잠금) 뒤에도 draft 답 유지 ----
E.tick(3000);
const vi = E.call({ action: 'violation', sid, token: tok, studentNo: '2012111', eventId: 'e1', kind: 'hidden', phase: 'away' });
ok(vi.ok && vi.violations === 1, '이탈 1회 기록');
row = E.att(sid, '2012111');
ok(Object.keys(row.a.answers).length === 10, '잠금 요청이 draft 답을 기록에 합침');

// ---- 3. 잠금 경합 중 제출 → 접수 ----
const en2 = E.call({ action: 'enter', sid, studentNo: '25B3003', name: '라마바' });
const ans2 = {}; en2.questions.forEach(q => { ans2[q.qid] = q.type === 'mc' ? 1 : '응답'; });
E.tick(60000);
E.lockState.busy = true;
const subAt = 1800000000000 + 5000 + 3000 + 60000;
const sq = E.call({ action: 'submit', sid, token: en2.token, studentNo: '25B3003', answers: ans2 });
ok(sq.ok && sq.queued && sq.status === 'submitted' && sq.result && sq.result.released === false, '잠금 실패 제출은 접수 완료로 응답');
row = E.att(sid, '25B3003');
ok(row.status === 'in_progress' && row.draft && row.draft.submit === true && row.draft.at === subAt, '시트에는 제출 접수(draft.submit)로 남음');
ok(E.cache.qpend === '1', '접수 표시');
// 접수 뒤 늦게 온 자동 저장(창 닫힘 신호)은 접수를 덮어쓰지 않는다
E.tick(1000);
const sv2 = E.call({ action: 'save', sid, token: en2.token, studentNo: '25B3003', answers: { q1: 3 } });
ok(sv2.ok && sv2.queued, '접수 뒤 저장 요청은 접수 상태로 응답');
ok(E.att(sid, '25B3003').draft.submit === true, '접수 기록 유지');
// 같은 제출을 다시 보내도 접수 상태
const sq2 = E.call({ action: 'submit', sid, token: en2.token, studentNo: '25B3003', answers: ans2 });
ok(sq2.ok && sq2.queued, '중복 제출도 접수 상태');
// 학생 결과 조회: 채점 대기
const mr = E.call({ action: 'myResult', sid, studentNo: '25B3003', name: '라마바' });
ok(mr.ok && mr.result.queued, '결과 조회: 접수(채점 대기)');
const mh = E.call({ action: 'myHistory', studentNo: '25B3003', name: '라마바' });
ok(mh.ok && mh.sessions ? true : mh.ok, '내 기록 조회 성공');
E.lockState.busy = false;

// ---- 4. 다음 잠금 요청이 접수분을 채점 ----
E.tick(2000);
const en3 = E.call({ action: 'enter', sid, studentNo: '23B3015', name: '사아자' });
ok(en3.ok, '다른 학생 입장');
const stl = E.call({ action: 'settle' });
ok(stl.ok && stl.settled === 1, '학생 화면의 settle 요청이 접수분 채점');
row = E.att(sid, '25B3003');
ok(row.status === 'submitted' && row.a.endReason === 'submit' && row.a.submittedAt === subAt && row.a.queuedAt === subAt, '접수분이 학생 제출 시각으로 채점·확정');
ok(Object.keys(row.a.answers).length === 10 && row.draft === null, '답 10개 확정, draft 비움');
ok(typeof row.a.score === 'number', '점수 저장 ' + row.a.score);
E.call({ action: 'violation', sid, token: en3.token, studentNo: '23B3015', eventId: 'x9', kind: 'blur', phase: 'return' });
ok(!E.cache.qpend, '대기 없으면 다음 잠금 요청에서 표시 지움');

// ---- 5. 제한 시간 넘긴 접수 → timeout ----
const en4 = E.call({ action: 'enter', sid, studentNo: '24B3005', name: '차카타' });
E.tick(25 * 60000);
E.lockState.busy = true;
const sq4 = E.call({ action: 'submit', sid, token: en4.token, studentNo: '24B3005', answers: {} });
ok(sq4.ok && sq4.queued, '시간 넘겨 접수');
E.lockState.busy = false;
// ---- 6. 교수 화면 열람이 접수분을 채점 ----
const d2 = E.call({ action: 'sessionDetail', adminToken: adm, id: sid });
const r4 = d2.attempts.find(a => a.no === '24B3005');
ok(r4 && r4.status === 'submitted' && r4.endReason === 'timeout', '교수 화면 열 때 접수분 채점(시간 초과 판정)');

// ---- 7. 제출 마무리: 접수분은 학생 제출로, 남은 응시는 교수 제출 처리 ----
const en5 = E.call({ action: 'enter', sid, studentNo: '22B3022', name: '파하' });
E.call({ action: 'save', sid, token: en5.token, studentNo: '22B3022', answers: { [en5.questions[0].qid]: 0 } });
const en6 = E.call({ action: 'enter', sid, studentNo: '25B2015', name: '거너' });
E.lockState.busy = true;
E.call({ action: 'submit', sid, token: en6.token, studentNo: '25B2015', answers: { [en6.questions[1].qid]: 1 } });
E.lockState.busy = false;
delete E.cache.qpend;   // 캐시가 날아가도
const fz = E.call({ action: 'finalizeSession', adminToken: adm, id: sid });
ok(fz.ok && fz.finalized.length === 3 && fz.queuedGraded === 1, '마무리: 응시 중 3명 교수 처리, 접수 1명 채점 ' + JSON.stringify([fz.finalized && fz.finalized.map(f => f.no), fz.queuedGraded]));
ok(E.att(sid, '25B2015').a.endReason === 'submit', '접수분은 교수 처리로 바뀌지 않음');
ok(Object.keys(E.att(sid, '22B3022').a.answers).length === 1, '잠금 없이 저장한 답도 마무리에 반영');
ok(E.book.sheets.attempts.data.slice(1).every(r => r[4] !== 'in_progress'), '모두 확정');

// ---- 8. 잠금 기다리기 실패: 입장은 busy로(학생 화면이 자동 재시도) ----
E.lockState.busy = true;
const eb = E.call({ action: 'enter', sid, studentNo: '30B0001', name: '테스트' });
ok(!eb.ok && eb.code === 'busy', '새 행 자리 잡기는 짧은 잠금 필요: 막히면 busy(학생 화면이 자동 재시도)');
E.lockState.busy = false;

// ---- 9. 다른 이름으로 같은 학번 막기(학번·이름 열만 읽기) ----
const s2 = E.call({ action: 'createSession', adminToken: adm, title: '모의2', questions: g.questions, status: 'open' });
const nm = E.call({ action: 'enter', sid: s2.session.id, studentNo: '2012111', name: '다른이름' });
ok(!nm.ok && nm.code === 'name_mismatch', '숫자 학번도 이름 불일치 감지');

// ---- 10. 부하 점검 회기 ----
E.ctx.loadTestPrepare();
const lt = JSON.parse(E.ctx.$log.find(l => l.startsWith('LOADTEST ')).slice(9));
ok(lt.sid && lt.key, '점검 회기 준비');
const lo = E.call({ action: 'listOpen' });
ok(lo.ok && !lo.sessions.some(s => s.id === lt.sid), '학생 목록에 점검 회기 숨김');
const lsess = E.call({ action: 'listSessions', adminToken: adm });
ok(!lsess.sessions.some(s => s.id === lt.sid), '교수 목록에도 숨김');
E.props.ROSTER = JSON.stringify([{ no: '2012111', name: '가나다' }]);   // 명단이 있어도 점검 학생은 입장
const lts = [];
for (let i = 0; i < 40; i++) { const r = E.call({ action: 'enter', sid: lt.sid, studentNo: 'LT' + (1000 + i), name: '점검' + i }); lts.push(r); }
ok(lts.every(r => r.ok), '점검 학생 40명 입장(명단 무시)');
lts.forEach((r, i) => { E.call({ action: 'save', sid: lt.sid, token: r.token, studentNo: 'LT' + (1000 + i), answers: { [r.questions[0].qid]: 0, [r.questions[1].qid]: 1 } }); });
E.lockState.busy = true;
lts.forEach((r, i) => { if (i % 2) E.call({ action: 'submit', sid: lt.sid, token: r.token, studentNo: 'LT' + (1000 + i), answers: { [r.questions[0].qid]: 0, [r.questions[1].qid]: 1, [r.questions[2].qid]: 2 } }); });
E.lockState.busy = false;
lts.forEach((r, i) => { if (!(i % 2)) E.call({ action: 'submit', sid: lt.sid, token: r.token, studentNo: 'LT' + (1000 + i), answers: { [r.questions[0].qid]: 0, [r.questions[1].qid]: 1, [r.questions[2].qid]: 2 } }); });
const bad = E.call({ action: 'loadTestFinish', key: 'wrong' });
ok(!bad.ok, '키 틀리면 거부');
const fin = E.call({ action: 'loadTestFinish', key: lt.key });
ok(fin.ok && fin.stats.total === 40 && fin.stats.submitted === 40 && fin.stats.queuedGraded === 20 && fin.stats.answered[3] === 40, '점검 결과 40명 제출(접수 20명 포함), 답 3개씩 ' + JSON.stringify(fin.stats));
ok(!E.book.sheets.attempts.data.some(r => String(r[1]) === lt.sid) && !E.book.sheets.sessions.data.some(r => r[0] === lt.sid), '점검 기록 정리');
delete E.props.ROSTER;

// ---- 11. 예전 8열 기록과 호환 ----
const old = E.att(sid, '2012111');
ok(old && old.status === 'submitted', '기존 기록 읽기');

// ---- 12. 시트 읽기 양: 응시 기록이 많아도 저장·제출은 전체를 읽지 않는다 ----
const F = makeEnv();
const adm2 = F.call({ action: 'adminLogin', pw: 'pw' }).adminToken;
const cs3 = F.call({ action: 'createSession', adminToken: adm2, title: '많음', questions: g.questions, status: 'open' });
const s3 = cs3.session.id;
const sh = F.book.sheets.attempts;
for (let i = 0; i < 600; i++) sh.data.push(['old|' + i, 'old', 'X' + i, '옛', 'submitted', 50, JSON.stringify({ sid: 'old', no: 'X' + i, name: '옛', status: 'submitted', answers: {}, violations: [], order: [], optOrder: {} }), new Date(), '']);
const e7 = F.call({ action: 'enter', sid: s3, studentNo: 'NEW1', name: '새' });
const before = F.ops.read;
F.call({ action: 'save', sid: s3, token: e7.token, studentNo: 'NEW1', answers: {} });
const saveReads = F.ops.read - before;
ok(saveReads <= 6, '저장 1회 시트 읽기 ' + saveReads + '회(전체 읽기 없음)');


// ---- 13. 입장: 잠금 없이 첫 입장, 같은 화면 재요청은 이탈 아님, 새로고침은 이탈 1회 ----
{
  const G = makeEnv();
  const ad = G.call({ action: 'adminLogin', pw: 'pw' }).adminToken;
  const c = G.call({ action: 'createSession', adminToken: ad, title: '입장', questions: g.questions, status: 'open' });
  const S = c.session.id;
  const a1 = G.call({ action: 'enter', sid: S, studentNo: '25B0001', name: '하나', eid: 'E1' });
  ok(a1.ok && a1.status === 'in_progress', '첫 입장');
  ok(G.ops.flush >= 1, '새 행을 쓴 뒤 잠금을 넘기기 전에 확정(flush)');
  G.lockState.busy = true;
  const a2 = G.call({ action: 'enter', sid: S, studentNo: '25B0001', name: '하나', eid: 'E1' });
  ok(a2.ok && a2.resumed && a2.violations === 0 && a2.token === a1.token, '같은 화면 재요청: 이탈 아님');
  const a3 = G.call({ action: 'enter', sid: S, studentNo: '25B0001', name: '하나', eid: 'E2' });
  ok(!a3.ok && a3.code === 'busy', '새로고침 재입장은 잠금이 필요(막히면 busy → 학생 화면 재시도)');
  G.lockState.busy = false;
  const a4 = G.call({ action: 'enter', sid: S, studentNo: '25B0001', name: '하나', eid: 'E2' });
  ok(a4.ok && a4.violations === 1 && a4.reentered, '새로고침 재입장은 이탈 1회(기존 규칙)');
  const a5 = G.call({ action: 'enter', sid: S, studentNo: '25B0001', name: '하나', eid: 'E2' });
  ok(a5.ok && a5.violations === 1, '그 화면의 재요청은 추가로 세지 않음');
  // 같은 학번 동시 첫 입장(두 행) → 먼저 생긴 행이 주인
  const shA = G.book.sheets.attempts;
  const fake = { sid: S, no: '25B0002', name: '둘', status: 'in_progress', startedAt: 1, updatedAt: 1, token: 'tFIRST', order: g.questions.map((q, i) => 'q' + (i + 1)), optOrder: {}, answers: {}, violations: [], entries: 1, eid: 'X' };
  shA.data.push([S + '|25B0002', S, '25B0002', '둘', 'in_progress', '', JSON.stringify(fake), new Date(), '']);
  // 두 요청이 동시에 「기록 없음」을 보고 각자 행을 덧붙인 상황: 늦은 쪽의 addAttempt
  G.ctx.GAS_MEMO_ = {};
  const won = G.ctx.GasStore.addAttempt(Object.assign({}, fake, { token: 'tSECOND', eid: 'Y' }));
  ok(won.token === 'tFIRST', '같은 학번 동시 첫 입장: 먼저 생긴 행으로 이어짐');
  ok(shA.data.filter(r => r[0] === S + '|25B0002').length === 1 && shA.data.some(r => r[0] === 'dup|' + S + '|25B0002'), '늦게 생긴 행은 무효 표시');
  const det = G.call({ action: 'sessionDetail', adminToken: ad, id: S });
  ok(det.attempts.filter(x => x.no === '25B0002').length === 1, '교수 화면에 한 명으로 표시');
  // settle: 접수분 채점
  const e9 = G.call({ action: 'enter', sid: S, studentNo: '25B0003', name: '셋', eid: 'Z' });
  G.lockState.busy = true;
  const q9 = G.call({ action: 'submit', sid: S, token: e9.token, studentNo: '25B0003', answers: {} });
  G.lockState.busy = false;
  ok(q9.queued, '접수');
  const st9 = G.call({ action: 'settle' });
  ok(st9.ok && st9.settled === 1 && G.att(S, '25B0003').status === 'submitted', 'settle 요청이 접수분 채점');
  // 학생 첫 화면 캐시는 회기를 바꾸면 바로 지워진다
  const lo1 = G.call({ action: 'listOpen' }); ok(lo1.sessions.some(x => x.id === S), '열린 회기 보임');
  G.call({ action: 'updateSession', adminToken: ad, id: S, patch: { status: 'closed' } });
  const lo2 = G.call({ action: 'listOpen' }); ok(!lo2.sessions.some(x => x.id === S), '마감 즉시 목록에서 사라짐(캐시 지움)');
  // 행 번호 캐시가 틀려도(행이 지워져 밀림) 맞는 행을 찾는다
  G.cache['r:' + S + '|25B0003'] = '2';
  const mr9 = G.call({ action: 'myResult', sid: S, studentNo: '25B0003', name: '셋' });
  ok(mr9.ok && mr9.status === 'submitted', '틀린 행 번호 캐시 무시');
}

console.log((fail ? '실패 ' + fail + ' / ' : '') + 'Apps Script 모의 시험 통과 ' + pass);
process.exit(fail ? 1 : 0);
