
/* 체험판(로컬 시험용) 저장소: 이 브라우저 localStorage. 배포본에는 들어가지 않는다. */
(function () {
  var K = 'quizdemo_v1';
  function load() { var d; try { d = JSON.parse(localStorage.getItem(K)) || {}; } catch (e) { d = {}; } d.sessions = d.sessions || {}; d.attempts = d.attempts || {}; d.props = d.props || { ADMIN_PW: 'demo1234' }; d.log = d.log || []; return d; }
  var db = load(); db.sessions = db.sessions || {}; db.attempts = db.attempts || {}; db.props = db.props || { ADMIN_PW: 'demo1234' }; db.log = db.log || [];
  function save() { try { localStorage.setItem(K, JSON.stringify(db)); } catch (e) { } }
  var cache = {};
  var store = {
    now: function () { return Date.now() + (window.DEMO_SKEW || 0); }, random: Math.random,
    sha256: function (s) { return 'x' + s; },
    cacheGet: function (k) { var c = cache[k] || JSON.parse(sessionStorage.getItem('dc_' + k) || 'null'); return c && c.exp > Date.now() ? c.v : null; },
    cachePut: function (k, v, sec) { var c = { v: v, exp: Date.now() + sec * 1000 }; cache[k] = c; try { sessionStorage.setItem('dc_' + k, JSON.stringify(c)); } catch (e) { } },
    getProp: function (k) { db = load(); db.props = db.props || { ADMIN_PW: 'demo1234' }; return db.props[k] || null; },
    setProp: function (k, v) { db = load(); db.props[k] = v; save(); },
    log: function (r) { db.log.push(r); save(); },
    listSessions: function () { db = load(); db.sessions = db.sessions || {}; return Object.keys(db.sessions).map(function (k) { return db.sessions[k]; }); },
    getSession: function (id) { db = load(); return (db.sessions || {})[id] || null; },
    putSession: function (s) { db = load(); db.sessions[s.id] = s; save(); },
    deleteSession: function (id) { db = load(); delete db.sessions[id]; save(); },
    getAttempt: function (sid, no) { db = load(); return (db.attempts || {})[sid + '|' + no] || null; },
    putAttempt: function (a) { db = load(); db.attempts[a.sid + '|' + a.no] = a; save(); },
    deleteAttempt: function (sid, no) { db = load(); delete db.attempts[sid + '|' + no]; save(); },
    listAttempts: function (sid) { db = load(); return Object.keys(db.attempts || {}).map(function (k) { return db.attempts[k]; }).filter(function (a) { return a.sid === sid; }); },
    listAttemptsByStudent: function (no) { db = load(); return Object.keys(db.attempts || {}).map(function (k) { return db.attempts[k]; }).filter(function (a) { return a.no === no; }); }
  };
  window.DEMO_BACKEND = { handle: function (req) { return new Core(store, BANK, OUTLINE).handle(req); }, reset: function () { localStorage.removeItem(K); } };
})();
